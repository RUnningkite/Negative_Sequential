package algorithm.XJ;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;
import java.util.HashMap;

import sequence.*;
import sys.*;
import data.*;

/**
 * <title>GSP Algorithm Class</title>
 * core class, run gsp algorithm
 */

public class XJ {  
    private ArrayList<Sequence> c; //candidate set
    private ArrayList<Sequence> l; //sequence set
    private ArrayList<Sequence> lneg;
    private ArrayList<Sequence> lresult;  //save temp result;
    
    public SeqDB source_db;
    private double min_sup;
    
    private int memory=0;
    private int support;
    
    private int avg=0;
    private int sidcount=0;
    private boolean negative = false;
    private ArrayList<SeqDB> pattern_db; //all sequences list
    private ArrayList<SeqDB> pattern_db_neg; //all sequences list
    
    public logfile log;
    private long sumruntime=0;
    private long posruntime=0;
    private long NSCsum=0;
    private String SequenceCountString="";
    
    private SequenceHash seqh = new SequenceHash();
    
    private ArrayList<Hashtable> SetIDList;
	
    public boolean isDebug = false;

   /**
    * 
    * @param support
    */
    public XJ(double min_sup) {
        this.min_sup = min_sup;                   
        this.source_db = new SeqDB();                    //get data from class SeqDB
        log = new logfile();
        SetIDList = new ArrayList<Hashtable>();
    }
    public XJ(double min_sup, String logfile) {
        this.min_sup = min_sup;                   
        this.source_db = new SeqDB();                    //get data from class SeqDB
        log = new logfile(logfile);
        SetIDList = new ArrayList<Hashtable>();
    }

    /**
     * Load training data from file, 
     * @param loadtype
     * @param datafilename
     */
    public boolean setdatasource(int loadtype,String filename){
    	if (source_db!=null){
    		source_db.loaddata(loadtype,filename);
    		return true;
    	}
    	else return false;
    }
    
    public void setdatasource(SeqDB sdb){
    	if (source_db!=null){
    		source_db = sdb;
    	} else {
    		source_db = new SeqDB(sdb.getSeqs());
    	}
    }

    
    /**
     * get all positive sequence set
     * core method, call join and prune method; then save to the result
     * @return sequence set
     */
    public ArrayList getSequences() {
        
    	long start = System.currentTimeMillis();
    	//long start = System.nanoTime();
        pattern_db = new ArrayList<SeqDB>();
        pattern_db_neg = new ArrayList<SeqDB>();
        
        this.support = (int) (this.min_sup * source_db.getSeqs().size());
    
        initialize();
        
        for (Sequence s: l){
        	log.println(s.outputToString());
        }  
        
        int i=0;
        while (l.size()>0){
            //generate candidate after join
            genCandidate();      
            if ( c.size() <= 0 ) {
                break;
            }
            if (isDebug) log.println("before prune, pos candidate set is:["+c.size()+"] patterns, c is :"+c);
            pruneC();
            if (isDebug) log.println("after prune, pos candidate set is:["+c.size()+"] patterns, c is :"+c);
            //generate sequential patterns
            generateL();
            if (isDebug) log.println("pos sequential pattern L(" + (i + 2) + ") is: [" +l.size()+ "] patterns:" + l);
            addToResult(l);
            
            //ArrayList<Sequence> lneg = new ArrayList<Sequence>();
            //lneg = generateLNeg(l);
            
            //addToResultNeg(lneg);
            
            for (Sequence s: l){
            	log.println(s.outputToString());
            }   
            //for (Sequence s: lneg){
            //	log.println(s.outputToString());
            //}  
            i++;
        }
        long end = System.currentTimeMillis();
        //long end = System.nanoTime();
        posruntime = end - start;
        log.println("running time is " + (end - start) + "ms!");

        getNegSequences();                
        end = System.currentTimeMillis();
       // end = System.nanoTime();
        sumruntime = end - start;
        
        return pattern_db;
    }
    
    public void getNegSequences() {
    	
    	long start = System.nanoTime();
    	
    	 for (int j=1; j< pattern_db.size(); j++){
         	SeqDB sdb = pattern_db.get(j);
         	ArrayList<Sequence> l = sdb.getSeqs();
         	ArrayList<Sequence> lneg = new ArrayList<Sequence>();
            lneg = generateLNeg(l);
                
            addToResultNeg(lneg);         	
         }
    	 
    	 int iflag = 0;
         for (int j=0; j< pattern_db_neg.size(); j++){
         	SeqDB sdb = pattern_db_neg.get(j);
         	//System.out.println("sdb = " + sdb.size()+ ",,");
         	for (int k=0;k<sdb.getSeqs().size();k++){
         		Sequence s = sdb.getSeqs().get(k);
         		log.println( iflag + "|" + s.outputToString() );
         		iflag ++;
         	}         	
         }    
         
         long end = System.nanoTime();
         log.println("running time is " + (end - start) + "ms!");
    }

    /*
     * initial method
     */
    private void initialize() {

  //      Map<Integer, Integer> can1 = new HashMap<Integer, Integer>();
        Map<Integer, Integer> can = new HashMap<Integer, Integer>();
        Map<Integer, Integer> arr;

        //all positive 1-item set
        for (Sequence s : source_db.getSeqs()) {
            //for all sequence in data set
        	arr = new HashMap<Integer, Integer>();
            for (Element e : s.getElements()) {
                //for all elements in sequence
                for (int i : e.getItems()) {
                    arr.put(i,i);
                }
            }
            for (int i: arr.values()){
            	if (can.containsKey(i)) {
                    int count = can.get(i).intValue() + 1;
                    can.put(i, count);
                } else {
                    can.put(i, 1);
                }
            }        	
        }
        
        this.l = new ArrayList<Sequence>();

        //for all candidate set, if greater than min support, 
        //then add it into sequential pattern set L
        for (int i : can.keySet()) {
        	int ivalue = can.get(i).intValue();      
        	
        	if ( i > 0 && ivalue > support ) { //positive pattern
                Element e = new Element(new int[] {i});
                Sequence seq = new Sequence();
                seq.addElement(e);
                seq.setSupport(ivalue);
                this.l.add(seq);
                //log.println(seq.toString() + " support = " +ivalue);
            }
        }

        Hashtable ht = new Hashtable();
        for (Sequence seq: l){
			ht.put(seq.toString(),(seq.getSupport()*10));//10鍊�
			//ht.put(seq.toString(),seq.getSupport());
			//System.out.println(seq.toString());
        }
       
        memory =l.size()*32;//鍐呭瓨璁＄畻
        SetIDList.add(ht);
        ArrayList<Sequence> lneg = generateLNeg(l);
        addToResultNeg(lneg);
        
        //add to result set
        this.addToResult(l);
        
    }
    
    /*
     * generate candidate set by join operation
     */
    private void genCandidate() {

        this.c = new ArrayList<Sequence>();
        
        seqh.getHashTable().clear();
        
        //join among sequential pattern set L
        for (int i = 0; i < this.l.size(); i++) {
            for (int j = i; j < this.l.size(); j++) {
            	this.joinAndInsert(l.get(i), l.get(j));
                if (i != j) {
                    this.joinAndInsert(l.get(j), l.get(i));  
                }
            }
        }
    }


   /*
    * Join method between two sequence
    */
    private void joinAndInsert(Sequence s1, Sequence s2){
    
    	Sequence s, st;
        //remove first element
        Element ef = s1.getElement(0).getWithoutFistItem(); 
        //remove last element
        Element ee = s2.getElement(s2.size() - 1).getWithoutLastItem();
        
        int i = 0, j = 0;
        if (ef.size() == 0) {
            i++;
        }
        for (; i < s1.size() && j < s2.size(); i++, j++) {
            Element e1, e2;
            if (i == 0) {
                e1 = ef;
            } else {
                e1 = s1.getElement(i);
            }
            if (j == s2.size() - 1) {
                e2 = ee;
            } else {
                e2 = s2.getElement(j);
            }
            if (!e1.equalsTo(e2)) {
                return;
            }
        }
        
       
        if (s1.size()==1 || s2.getElement(s2.size()-1).size()>1) {
        	//add the last item of s2 into s
            s = new Sequence(s1);
            int slast = s.getElement(s.size() - 1).getLastItem();
            int s2last = s2.getElement(s2.size()-1).getLastItem();
            if (slast>0 && s2last > 0 && slast!=s2last) {
             	(s.getElement(s.size() - 1)).addItem(s2last);
             	//log.print("S1=" + s1.toString() + "=s2=" + s2.toString());
            	//log.println("=s=" + s.toString());
            	if (!s.isInSeqs(seqh)) { 
                	c.add(s);
                	seqh.put(s);
                }
            }    
        }
        
        if (s1.size()==1 || s2.getElement(s2.size()-1).size()==1) {
        	//add the last element of s2 into s        
            st = new Sequence(s1);
            int s2end = s2.getElement(s2.size()-1).getLastItem();
            st.addElement(new Element(new int[] {s2end}));
            //log.print("S1=" + s1.toString() + "=s2=" + s2.toString());
        	//log.println("=st=" + st.toString());
            if (!st.isInSeqs(seqh) ){
            	c.add(st); 
        	    seqh.put(st);
            }
        }
        
    }

    /*
     * Prune Operation
     * verify whether every continuous sub sequence of candidate set is frequent
     * get element one by one, remove one element, to see whether sub sequence is in L
     */
    private void pruneC() {
        Sequence s;
        
        SequenceHash lhash = new SequenceHash();       	
        for (Sequence stemp: l){
        	lhash.put(stemp);
        } 
        
        //for all element in sequence
        for (int i = 0; i < this.c.size();i++) {
            s = c.get(i);
            boolean is = false;
            //for all items in element
            for (int j = 0; j < s.size(); j++) {
                Element ce = s.getElement(j);
                boolean prune=false;
                //only one element
                if (ce.size() == 1) {
                    s.removeElement(j);
                    //if sub sequence is not frequent, then remove it from candidate set, 
                    // otherwise add it into candidate set
                    if (!s.isInSeqs(lhash)) {   
                        prune=true;                        
                    }
                    s.insertElement(j, ce);
                } else {
                    for (int k = 0; k < ce.size(); k++) {
                        
                    	int item=ce.removeItem(k);
                        //if sub sequence is not frequent, then remove it from candidate set, 
                        // otherwise add it into candidate set
                        if (!s.isInSeqs(lhash)) {
                            prune=true;
                        }
                        ce.addItem(item); 
                    }
                }

                //if prune, then remove the sequence
                if(prune){
                    c.remove(i);
                    i--;
                    break;
                }
            }
        } 
    }


    /*
     * generate sequential pattern set L
     * after join and prune, get the data set
     */
    private void generateL() {
    	l.clear();
    	Hashtable ht = new Hashtable();
    	ArrayList<Integer> idlist;
        this.l = new ArrayList<Sequence>();
        for (Sequence seq : this.c) {  
        	if (seq.toString().equals("<12 12 12>")){
        		int ii;
        		ii=0;
        	}
        	idlist = new ArrayList<Integer>();
        	for (int i=0; i<source_db.getSeqs().size(); i++ ){
        		Sequence s = source_db.getSeqs().get(i);        		
        		if (seq.isMatch(s)) {
            		//count support
            		seq.incrementSupport();
            		idlist.add(i);
            		idlist.add((i+source_db.getSeqs().size()));//10鍊�
            		idlist.add((i+source_db.getSeqs().size()*2));
            		idlist.add((i+source_db.getSeqs().size()*3));
            		idlist.add((i+source_db.getSeqs().size()*4));
            		idlist.add((i+source_db.getSeqs().size()*5));
            		idlist.add((i+source_db.getSeqs().size()*6));
            		idlist.add((i+source_db.getSeqs().size()*7));
            		idlist.add((i+source_db.getSeqs().size()*8));
            		idlist.add((i+source_db.getSeqs().size()*9));
            	}
            }
        	if (seq.getSupport()>this.support){
        			if (seq.size()==1) {
        				ht.put(seq.toString(), idlist.size());
        				memory=memory+32;
        				seq.getElements();
        			}
        			else  {
        				ht.put(seq.toString(), idlist);
        				memory=memory+idlist.size()*32;
        				avg=avg+idlist.size();
        				sidcount=sidcount+1;
        			}
        			this.l.add(seq);
        			
        	}
        	System.out.println(seq);
        	 System.out.println("id"+idlist);
        }
        SetIDList.add(ht);
        System.out.println(SetIDList);
    }
    
    /*
     * generate negative sequential pattern set LNeg
     */
    private ArrayList<Sequence> generateLNeg(ArrayList<Sequence> l) {
    	ArrayList<Sequence> neglist = new ArrayList<Sequence>();
    	
    	for (int i=0; i<l.size(); i++){
    		Sequence seq = l.get(i);
    		
    		
    		if (seq.size()==1){  //1-element, include <(a b)>
    			int isup = getFromHash(SetIDList.get(seq.getElement(0).size()-1), seq.toString());
    			Sequence seqneg = new Sequence(seq);
    			seqneg = seqneg.getNegativeSequence();
    			NSCsum++;
    			seqneg.setSupport(source_db.size()*10 - isup);//10鍊�
    			if (seqneg.getSupport()>(this.support*10)){//10鍊�
    				neglist.add(seqneg);
    			}
    		} 	
    		
    		if (seq.size()>1){  //  more than 1-item
    			
//    			if (seq.toString().equals("<12 12 12 114 12>")){
//					int aa;
//					aa =0;
//				}
    			
    			// -----------------1-neg item-------------------
    			for (int j=0; j<seq.size(); j++){
    				
    				seq.getElement(j).setItemsNeg();
    				NSCsum++;
    				Sequence smp = seq.getPosFromSeq();
    				Sequence sce = seq.getCounterExample();//de dao fu xu lie de zheng zhuan zhi xu lie 
    				
    				
    				if (smp.size()==1){ 
    					int isup = getFromHash(SetIDList.get(smp.getElement(0).size()-1), smp.toString());
    					Sequence seqneg = new Sequence(seq);
    					
    					//System.out.println(seq.toString());
    					//System.out.println(smp.toString());
    					//;System.out.println(isup)
    					//System.out.println(sce.toString());
    					int isup0= getIDListFromHash(SetIDList.get(sce.itemsize()-1), sce.toString()).size();
    					isup=isup-isup0;
    					//System.out.println(isup0);
    					//isup = isup - getIDListFomHash(SetIDList.get(sce.itemsize()-1), sce.toString()).size();
    					seqneg.setSupport(isup);
    					//System.out.println(seqneg.getSupport());
    					if (seqneg.getSupport()>(this.support*10)){//10鍊�
            				neglist.add(seqneg);
            			}
    				}
    				if (smp.size()>1){ 
    					ArrayList<Integer> idlist1 = getIDListFromHash(SetIDList.get(smp.itemsize()-1), smp.toString()); 
    					ArrayList<Integer> idlist2 = getIDListFromHash(SetIDList.get(sce.itemsize()-1), sce.toString());
    					ArrayList<Integer> idlistdiff = getDiff(idlist1, idlist2);//涓庤鏂囦腑璨屼技涓嶄竴鏍�
    					Sequence seqneg = new Sequence(seq);    				
    					seqneg.setSupport(idlistdiff.size());
    					if (seqneg.getSupport()>(this.support*10)){//10bei
            				neglist.add(seqneg);
            			}
    				}
        			
        			seq.getElement(j).setItemsNeg();
    			}
    			
    			
    			// -------------------2-neg item---------------------
    			for (int j1=0; j1<seq.size(); j1++){
    				
    				for ( int j2=j1+2; j2<seq.size(); j2++){
    				
    					seq.getElement(j1).setItemsNeg();
    					seq.getElement(j2).setItemsNeg();
    					NSCsum++;
        				Sequence smp = seq.getPosFromSeq();
        				Sequence sce1 = seq.getCounterExampleX(0);
        				Sequence sce2 = seq.getCounterExampleX(1);
        				
        				if (smp.size()==1){ 
        					int isup = getFromHash(SetIDList.get(smp.getElement(0).size()-1), smp.toString());
        					ArrayList<Integer> idlist1 = getIDListFromHash(SetIDList.get(sce1.itemsize()-1), sce1.toString()); 
        					ArrayList<Integer> idlist2 = getIDListFromHash(SetIDList.get(sce2.itemsize()-1), sce2.toString());
        					ArrayList<Integer> idlistAnd = getAnd(idlist1, idlist2);
        					
        					Sequence seqneg = new Sequence(seq);
        					//System.out.println(seq.toString());
        					//System.out.println(smp.toString());
        					//System.out.println(sce.toString());
        					isup = isup - idlistAnd.size();
        					seqneg.setSupport(isup);
        					if (seqneg.getSupport()>(this.support*10)){
                				neglist.add(seqneg);
                			}
        				}
        				if (smp.size()>1){ 
        					ArrayList<Integer> idlist1 = getIDListFromHash(SetIDList.get(smp.itemsize()-1), smp.toString()); 
        					ArrayList<Integer> idlist2 = getIDListFromHash(SetIDList.get(sce1.itemsize()-1), sce1.toString());
        					ArrayList<Integer> idlist3 = getIDListFromHash(SetIDList.get(sce2.itemsize()-1), sce2.toString());
        					ArrayList<Integer> idlistAnd = getAnd(idlist2, idlist3);
        					ArrayList<Integer> idlistdiff = getDiff(idlist1, idlistAnd);
        					Sequence seqneg = new Sequence(seq);    				
        					seqneg.setSupport(idlistdiff.size());
        					if (seqneg.getSupport()>(this.support*10)){
                				neglist.add(seqneg);
                			}
        				}            			
            			seq.getElement(j1).setItemsNeg();
            			seq.getElement(j2).setItemsNeg();
    				}
    			}
    			
    			
    			// 3-neg item
    			
    			for (int j1=0; j1<seq.size(); j1++){
    				
    				for ( int j2=j1+2; j2<seq.size(); j2++){
    					
    					for ( int j3=j2+2; j3<seq.size(); j3++){ 
    				
    						seq.getElement(j1).setItemsNeg();
        					seq.getElement(j2).setItemsNeg();
        					seq.getElement(j3).setItemsNeg();
        					NSCsum++;
            				Sequence smp = seq.getPosFromSeq();
            				Sequence sce1 = seq.getCounterExampleX(0);
            				Sequence sce2 = seq.getCounterExampleX(1);
            				Sequence sce3 = seq.getCounterExampleX(2);            				
            			
            				if (smp.size()>1){ 
            					ArrayList<Integer> idlist1 = getIDListFromHash(SetIDList.get(smp.itemsize()-1), smp.toString()); 
            					ArrayList<Integer> idlist2 = getIDListFromHash(SetIDList.get(sce1.itemsize()-1), sce1.toString());
            					ArrayList<Integer> idlist3 = getIDListFromHash(SetIDList.get(sce2.itemsize()-1), sce2.toString());
            					ArrayList<Integer> idlist4 = getIDListFromHash(SetIDList.get(sce3.itemsize()-1), sce3.toString());
            					ArrayList<Integer> idlistAnd = getAnd(idlist2, idlist3);
            					idlistAnd = getAnd(idlistAnd, idlist4 );
            					ArrayList<Integer> idlistdiff = getDiff(idlist1, idlistAnd);
            					Sequence seqneg = new Sequence(seq);    				
            					seqneg.setSupport(idlistdiff.size());
            					if (seqneg.getSupport()>(this.support*10)){
                    				neglist.add(seqneg);
                    			}
            				}            			
                			seq.getElement(j1).setItemsNeg();
                			seq.getElement(j2).setItemsNeg();
                			seq.getElement(j3).setItemsNeg();
    					}
    				}
    			}
    			
    			// 4-neg item
    			for (int j1=0; j1<seq.size(); j1++){
    				
    				for ( int j2=j1+2; j2<seq.size(); j2++){
    					
    					for (int j3=j2+2; j3<seq.size(); j3++){
    						
    						for ( int j4=j3+2; j4<seq.size(); j4++){ 
    		    				
        						seq.getElement(j1).setItemsNeg();
            					seq.getElement(j2).setItemsNeg();
            					seq.getElement(j3).setItemsNeg();
            					seq.getElement(j4).setItemsNeg();
            					NSCsum++;
                				Sequence smp = seq.getPosFromSeq();
                				Sequence sce1 = seq.getCounterExampleX(0);
                				Sequence sce2 = seq.getCounterExampleX(1);
                				Sequence sce3 = seq.getCounterExampleX(2);      
                				Sequence sce4 = seq.getCounterExampleX(3);  
                			
                				if (smp.size()>1){ 
                					ArrayList<Integer> idlist1 = getIDListFromHash(SetIDList.get(smp.itemsize()-1), smp.toString()); 
                					ArrayList<Integer> idlist2 = getIDListFromHash(SetIDList.get(sce1.itemsize()-1), sce1.toString());
                					ArrayList<Integer> idlist3 = getIDListFromHash(SetIDList.get(sce2.itemsize()-1), sce2.toString());
                					ArrayList<Integer> idlist4 = getIDListFromHash(SetIDList.get(sce3.itemsize()-1), sce3.toString());
                					ArrayList<Integer> idlist5 = getIDListFromHash(SetIDList.get(sce4.itemsize()-1), sce4.toString());
                					ArrayList<Integer> idlistAnd = getAnd(idlist2, idlist3);
                					idlistAnd = getAnd(idlistAnd, idlist4 );
                					idlistAnd = getAnd(idlistAnd, idlist5 );
                					ArrayList<Integer> idlistdiff = getDiff(idlist1, idlistAnd);
                					Sequence seqneg = new Sequence(seq);    				
                					seqneg.setSupport(idlistdiff.size());
                					if (seqneg.getSupport()>(this.support*10)){
                        				neglist.add(seqneg);
                        			}
                				}            			
                    			seq.getElement(j1).setItemsNeg();
                    			seq.getElement(j2).setItemsNeg();
                    			seq.getElement(j3).setItemsNeg();
                    			seq.getElement(j4).setItemsNeg();
        					}
    					}
    				}
    			}
    			
    			// 5-neg item
    			for (int j1=0; j1<seq.size(); j1++){
    				
    				for ( int j2=j1+2; j2<seq.size(); j2++){
    					
    					for (int j3=j2+2; j3<seq.size(); j3++){
    						
    						for (int j4=j3+2; j4<seq.size(); j4++){
    							
    							for ( int j5=j4+2; j5<seq.size(); j5++){ 
        		    				
            						seq.getElement(j1).setItemsNeg();
                					seq.getElement(j2).setItemsNeg();
                					seq.getElement(j3).setItemsNeg();
                					seq.getElement(j4).setItemsNeg();
                					seq.getElement(j5).setItemsNeg();
                					NSCsum++;
                    				Sequence smp = seq.getPosFromSeq();
                    				Sequence sce1 = seq.getCounterExampleX(0);
                    				Sequence sce2 = seq.getCounterExampleX(1);
                    				Sequence sce3 = seq.getCounterExampleX(2);      
                    				Sequence sce4 = seq.getCounterExampleX(3);  
                    				Sequence sce5 = seq.getCounterExampleX(4);
                    			
                    				if (smp.size()>1){ 
                    					ArrayList<Integer> idlist1 = getIDListFromHash(SetIDList.get(smp.itemsize()-1), smp.toString()); 
                    					ArrayList<Integer> idlist2 = getIDListFromHash(SetIDList.get(sce1.itemsize()-1), sce1.toString());
                    					ArrayList<Integer> idlist3 = getIDListFromHash(SetIDList.get(sce2.itemsize()-1), sce2.toString());
                    					ArrayList<Integer> idlist4 = getIDListFromHash(SetIDList.get(sce3.itemsize()-1), sce3.toString());
                    					ArrayList<Integer> idlist5 = getIDListFromHash(SetIDList.get(sce4.itemsize()-1), sce4.toString());
                    					ArrayList<Integer> idlist6 = getIDListFromHash(SetIDList.get(sce5.itemsize()-1), sce5.toString());
                    					ArrayList<Integer> idlistAnd = getAnd(idlist2, idlist3);
                    					idlistAnd = getAnd(idlistAnd, idlist4 );
                    					idlistAnd = getAnd(idlistAnd, idlist5 );
                    					idlistAnd = getAnd(idlistAnd, idlist6 );
                    					ArrayList<Integer> idlistdiff = getDiff(idlist1, idlistAnd);
                    					Sequence seqneg = new Sequence(seq);    				
                    					seqneg.setSupport(idlistdiff.size());
                    					if (seqneg.getSupport()>(this.support*10)){
                            				neglist.add(seqneg);
                            			}
                    				}            			
                        			seq.getElement(j1).setItemsNeg();
                        			seq.getElement(j2).setItemsNeg();
                        			seq.getElement(j3).setItemsNeg();
                        			seq.getElement(j4).setItemsNeg();
                        			seq.getElement(j5).setItemsNeg();
            					}
    						}
    					}
    				}
    			}
    		} 	
    	}
    	//
    	return neglist;
    }
    
    private ArrayList<Integer> getDiff(ArrayList<Integer> listSupperSet, ArrayList<Integer> listSubSet){
    	
    	ArrayList<Integer> l1 = new ArrayList<Integer>();
    	ArrayList<Integer> l2 = new ArrayList<Integer>();
    	for (int i=0; i<listSupperSet.size(); i++){
    		l1.add(listSupperSet.get(i));
    	}
    	for (int i=0; i<listSubSet.size(); i++){
    		l2.add(listSubSet.get(i));
    	}
    	
    	int i=0, j=0;
    	while ( i < l1.size() && j < l2.size() ){
    			int i1 = l1.get(i);
    			int i2 = l2.get(j);
    			
    			if ( i1 == i2) {
    				l1.remove(i);
    				//l2.remove(j);
    				j++;
    			} else if ( i1 > i2) {
    				j++;
    			} else {
    				i++;
    			}
    	}    	
    	
    	return l1;
    	
    }
    
    
private ArrayList<Integer> getAnd(ArrayList<Integer> listSupperSet, ArrayList<Integer> listSubSet){
    	
	/*
    	ArrayList<Integer> l1 = new ArrayList<Integer>();
    	ArrayList<Integer> l2 = new ArrayList<Integer>();
    	for (int i=0; i<listSupperSet.size(); i++){
    		l1.add(listSupperSet.get(i));
    	}
    	for (int i=0; i<listSubSet.size(); i++){
    		l2.add(listSubSet.get(i));
    	}
    	
    	int i=0, j=0;
    	while ( i < l1.size() && j < l2.size() ){
    			int i1 = l1.get(i);
    			int i2 = l2.get(j);
    			
    			if ( i1 > i2) {
    				l1.add(i,i2);
    				//i++;
    				j++;
    			} else if ( i1 < i2) {
    				i++;
    			} else {
    				i++;
    				j++;
    			}
    	}    	
    	
    	return l1;
    	*/  
			ArrayList<Integer> l1 = new ArrayList<Integer>();
	    	ArrayList<Integer> l2 = new ArrayList<Integer>();
	    	ArrayList<Integer> l3 = new ArrayList<Integer>();
	    	for (int i=0; i<listSupperSet.size(); i++){
	    		l1.add(listSupperSet.get(i));
	    	}
	    	for (int i=0; i<listSubSet.size(); i++){
	    		l2.add(listSubSet.get(i));
	    	}
	    	
	    	int i=0, j=0;
	    	while ( i < l1.size() && j < l2.size() ){
	    			
	    			
	    			int i1 = l1.get(i);
	    			int i2 = l2.get(j);
	    			
	    			if ( i1 > i2) {
	    				l3.add(i2);	    				
	    				j++;
	    			} else if ( i1 < i2) {
	    				l3.add(i1);
	    				i++;
	    			} else {
	    				l3.add(i1);
	    				i++;
	    				j++;
	    			}
	    	}  
	    	
	    	while (i<l1.size()) {
	    		l3.add(l1.get(i));
	    		i++;
	    	}
	    	while (j<l2.size()) {
	    		l3.add(l2.get(j));
	    		j++;
	    	}
	    	
	    	return l3;
		
	
    	
    }
    
    private int getFromHash(Hashtable ht, String strKey){
    	int isup = 0;
    	
    	isup = (Integer)ht.get(strKey);
    	
    	return isup;
    }
    
    private ArrayList<Integer> getIDListFromHash(Hashtable ht, String strKey){
    	ArrayList<Integer> strList = new ArrayList<Integer>();
    	
    	strList = (ArrayList<Integer>)ht.get(strKey);
    	
    	return strList;
    }
    
    
    
   
    /*
     * add the frequent sequence pattern into result set
     */
    private void addToResult(ArrayList<Sequence> l) { 
        
    	pattern_db.add(new SeqDB(l));
    }
    
    private void addToResultNeg(ArrayList<Sequence> l) { 
        
    	pattern_db_neg.add(new SeqDB(l));
    }

    /**
     * output the sequential pattern
     */
   public void outputInput() {
          log.println("support is: " + this.support);
          log.println("");
   }
   
   /**
    * set algorithm type, whether it can do negative sequence mining
    */
   public void setNegative(boolean isNeg){
	   this.negative = isNeg;
   }
   
   public long getSumRuntime(){
	   return sumruntime;
   }
   
   public long getPosRuntime(){
	   return posruntime;
   }

   public long getNSCsum(){
	   return NSCsum;
   }
   public String getSequenceCountString(){
	   return SequenceCountString;
   }
   public double getmemory() {

	   double mey=(double)memory;
	   mey=(mey/(1024*1024));
	   return mey;
}
   public double getsidavg() {

	   double sidavg=(double)avg;
	   sidavg=(sidavg/sidcount);
	   return sidavg;
}
   
   public int getPatternsCount(){
	   
	   int iCount = 0;
	   for (int j=0; j< pattern_db_neg.size(); j++){
       		SeqDB sdb = pattern_db_neg.get(j);
       		for (int k=0;k<sdb.getSeqs().size();k++){
       			iCount ++;
       		}       	
       }
	   return iCount;
   }
}

