package algorithm;

import algorithm.gsp.GSP;
import algorithm.presnsp.PreNsp;
import junit.framework.TestCase;

import java.io.IOException;

/**
 * test class Use junit to do test
 *
 */

public class test extends TestCase {

	public void test() throws IOException {

		// ----Algorithm ----
		int type = 0; // 1 GSP; 2 XJ algorithm;

		// ----Result Output ----
		String logfile = "D:\\ceshi\\";

		String strDatapath;
		/*
		 * // simple test to calculate support
		 * 
		 * Sequence s = new Sequence(); Element e; int[] arrs1 = {-12}; int[]
		 * arrs2 = {12}; int[] arrs3 = {-12}; int[] arrs4 = {114}; int[] arrs5 =
		 * {-12};
		 * 
		 * e = new Element(arrs1); s.addElement(e); e = new Element(arrs2);
		 * s.addElement(e); e = new Element(arrs3); s.addElement(e); e = new
		 * Element(arrs4); s.addElement(e); e = new Element(arrs5);
		 * s.addElement(e);
		 * 
		 * System.out.println(s.toString());
		 * 
		 * String log11 = logfile + "Match test " +System.currentTimeMillis()+
		 * ".txt"; GSP g = new GSP(0.1,log11); strDatapath =
		 * getDataSourcePath(5); g.setdatasource(4, strDatapath); for ( int i=0;
		 * i<g.source_db.getSeqs().size() ; i++) { Sequence seq =
		 * g.source_db.getSeqs().get(i); if (s.isXJNegMatch(seq)){
		 * //g.log.println(s.toString() + "=match=" + seq.toString());
		 * System.out.println(s.toString() + "=match=" + seq.toString()); } else
		 * { //g.log.println(s.toString() + "=notmatch=" + seq.toString());
		 * System.out.println(s.toString() + "=notmatch=" + seq.toString()); } }
		 */

		// ----Data Source ----
		int datasource; // Data Source

		// datasource = 1;
		// double[] sup1 = {0.24, 0.22, 0.2, 0.18, 0.16, 0.14, 0.12, 0.1};

		// datasource = 2;
		// double[] sup1 = {0.3, 0.2, 0.1, 0.08, 0.06};

		// datasource = 3;
		// double[] sup1 = {0.04, 0.03, 0.02, 0.01};

		datasource = 1;
		double[] sup1 = {0.04};

		for (int i = 0; i < sup1.length; i++) {

			type = 0;
			// -----------GSP Algorithm-----------------
			if (type == 1) {

				long start = System.currentTimeMillis();

				// logfile resultlog1 = new logfile(logfile + "ag"+ type + "_ds"
				// + datasource +
				// "result_time_"+System.currentTimeMillis()+".txt");
				// logfile resultlog2 = new logfile(logfile + "ag"+ type + "_ds"
				// + datasource +
				// "result_seq_"+System.currentTimeMillis()+".txt");

				double support = sup1[i];
				String log = logfile + "ag" + type + "_ds" + datasource + "_sup" + support + "_"
						+ System.currentTimeMillis() + ".txt";
				GSP gsp = new GSP(support, log);

				// GSP gsp = new GSP(support,log,1,1);
				strDatapath = getDataSourcePath(datasource);
				if (datasource == 1)
					gsp.setdatasource(3, strDatapath);
				if (datasource == 2)
					gsp.setdatasource(3, strDatapath);
				if (datasource == 3)
					gsp.setdatasource(2, strDatapath);
				if (datasource == 4)
					gsp.setdatasource(4, strDatapath);
				// -----System.out.println(gsp.source_db.lenaverage + ", min=" +
				// gsp.source_db.lenmin + ", max=" + gsp.source_db.lenmax +
				// ",size=" + gsp.source_db.size());
				gsp.setNegative(true);
				gsp.outputInput();
				gsp.getSequences();
				// System.out.println(Long.toString(gsp.getRuntime()));
				// System.out.println(gsp.getSequenceCountString());
				// resultlog1.println("ds=" + datasource + "||sup=" + support
				// + "||negtime=" + Long.toString(gsp.getRuntime())+"||"
				// + "||postime=" + Long.toString(gsp.getPosRuntime())+"||");
				// resultlog2.println("ds=" + datasource + "||sup=" + support +
				// gsp.getSequenceCountString());
				// resultlog2.println("");

				long end = System.currentTimeMillis();

				System.out.print("GSP|ds_" + datasource + "|sup=|" + support + "|patternscount_|");
				System.out.print("sumtime|" + gsp.getSumRuntime() + "|postime|" + gsp.getPosRuntime() + "|negtime|"
						+ (gsp.getSumRuntime() - gsp.getPosRuntime()));
				System.out.println();
			}

			type = 2;
			// -----------XJ Algorithm-----------------
			if (type == 2) {
				
				long start = System.currentTimeMillis();

				double support = sup1[i];
				String log = logfile + "ag" + type + "_ds" + datasource + "_sup" + support + "_"
						+ System.currentTimeMillis() + ".txt";
				PreNsp xj = new PreNsp(support, log);
				
				// GSP gsp = new GSP(support,log,1,1);
				strDatapath = getDataSourcePath(datasource);
				if (datasource == 1)
					xj.setdatasource(3, strDatapath);
				if (datasource == 2)
					xj.setdatasource(3, strDatapath);
				if (datasource == 3)
					xj.setdatasource(2, strDatapath);
				if (datasource == 4)
					xj.setdatasource(4, strDatapath);
				// System.out.println(gsp.source_db.lenaverage + ", min=" +
				// gsp.source_db.lenmin + ", max=" + gsp.source_db.lenmax +
				// ",size=" + gsp.source_db.size());
				
				xj.setNegative(true);
				xj.outputInput();
				
				xj.getSequences();

				long end = System.currentTimeMillis();

				System.out.print(
						"X J|ds_" + datasource + "|sup=|" + support + "|patternscount_" + xj.getPatternsCount() + "|");
				System.out.print("sumtime|" + xj.getSumRuntime() + "|postime|" + xj.getPosRuntime() + "|negtime|"
						+ (xj.getSumRuntime() - xj.getPosRuntime()));
				System.out.println();
				System.out.println("The number of NSCs:" + xj.getNSCsum());
			}
			type = 0;
			

		} // end for all support

	}

	private String getDataSourcePath(int datasource) {
		
		String strPath;

		String strDatapath = "D:\\ceshi\\";
		
		if (datasource == 1)
			strDatapath = strDatapath + "C4_T6_S4_I4_DB10k_N100.data.data";
		if (datasource == 2)
			strDatapath = strDatapath + "";
		
		if (datasource == 3)
			strDatapath = strDatapath + "";
		if (datasource == 4)
			strDatapath = strDatapath + "yongyang_mine_10times.data";

		return strDatapath;
	}

}
