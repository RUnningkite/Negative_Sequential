package algorithm;

import java.util.Date;

import algorithm.XJ.XJ;
import algorithm.gsp.GSP;


public class Run {

	public static void main(String[] argv) {
		// TODO Auto-generated method stub
		// try {

		if (VerifyInput(argv) == false) {
			PrintInputRequirement();
			return;
		}

		// ================================= Parameters
		// ==========================================================
		// System.out.println("Algorithm type: " + argv[0]); //parameter 1 :
		// Algorithm type: ENSP, NGSP, PNSP
		// System.out.println("Source Data File: " + argv[1]); //parameter 2 :
		// Source Data File
		// System.out.println("Source Data Format: " + argv[2]); //parameter 3 :
		// Source Data Format:1-4
		// System.out.println("Minimum Support: " + argv[3]); //parameter 4 :
		// Min_Sup
		// System.out.println("Output File Name: " + argv[4]); //parameter 5 :
		// Output File Name

		Date dStart = new Date();
		// System.out.println("======= Negative Pattern Mining Start Time: " +
		// dStart.toString() + "============");

		// parameter 1 : Algorithm type: ENSP, NGSP, PNSP
		String algorithmType = argv[0].trim().toUpperCase();
		// parameter 2 : Source Data File
		String sourceDataFileName = argv[1];
		// parameter 3 : Source Data Format
		String DataFormatType = argv[2];
		// parameter 4 : Min_Sup
		String Min_Sup = argv[3];
		// parameter 5 : Output File Name
		String outputFile = argv[4];

		double support = Double.parseDouble(Min_Sup);
		int dataFormat = Integer.parseInt(DataFormatType);

		// =====================================Run
		// Algorithm=================================================
		if (algorithmType.equals("NGSP")) {

			long start = System.currentTimeMillis();

			GSP gsp = new GSP(support, outputFile);

			// if (datasource==1) gsp.setdatasource(3, strDatapath);
			// if (datasource==2) gsp.setdatasource(3, strDatapath);
			// if (datasource==3) gsp.setdatasource(2, strDatapath);
			// if (datasource==4) gsp.setdatasource(4, strDatapath);
			gsp.setdatasource(dataFormat, sourceDataFileName);

			gsp.setNegative(true);
			gsp.outputInput();
			gsp.getSequences();

			long end = System.currentTimeMillis();

			System.out.print("GSP," + sourceDataFileName + ",sup=," + support + ",patternscount,"
					+ gsp.getPatternsCount() + ",");
			System.out.print("sumtime," + gsp.getSumRuntime() + ",postime," + gsp.getPosRuntime() + ",negtime,"
					+ (gsp.getSumRuntime() - gsp.getPosRuntime()));
			System.out.println();
		}

		if (algorithmType.equals("ENSP")) {

			long start = System.currentTimeMillis();
			XJ xj = new XJ(support, outputFile);

			// if (datasource==1) xj.setdatasource(3, strDatapath);
			// if (datasource==2) xj.setdatasource(3, strDatapath);
			// if (datasource==3) xj.setdatasource(2, strDatapath);
			// if (datasource==4) xj.setdatasource(4, strDatapath);
			xj.setdatasource(dataFormat, sourceDataFileName);

			xj.setNegative(true);
			xj.outputInput();
			xj.getSequences();

			long end = System.currentTimeMillis();

			System.out.print(
					"X J," + sourceDataFileName + ",sup=," + support + ",patternscount," + xj.getPatternsCount() + ",");
			System.out.print("sumtime," + xj.getSumRuntime() + ",postime," + xj.getPosRuntime() + ",negtime,"
					+ (xj.getSumRuntime() - xj.getPosRuntime()) + ",memory," + xj.getmemory() + "MB" + "avg"
					+ xj.getsidavg());
			// System.out.print(",memory,"+xj.getmemory()+"MB");
			System.out.println();
		}

	

		Date dEnd = new Date();
		// System.out.println("=======End Time: " + dEnd.toString() + ";
		// ======\n "
		// + " ========Cost time:" + (dEnd.getTime()-dStart.getTime())/1000 + "
		// seconds =======");

		// } catch (Exception e) {
		// System.err.println(e.getMessage());
		// }

	}

	private static boolean VerifyInput(String[] argv) {

		boolean bReturn = true;

		try {

			String strAlgorithmType = argv[0].toUpperCase();

			if (!strAlgorithmType.equals("NGSP") && !strAlgorithmType.equals("ENSP")
					&& !strAlgorithmType.equals("PNSP")) {
				bReturn = false;
				System.out.println("Error: The algorithm type should be one of ('ENSP', 'NGSP', 'PNSP');");
				return bReturn;
			}

			String strDataFormatType = argv[2].toUpperCase();
			int dataFormatType = Integer.parseInt(strDataFormatType);

			if (dataFormatType < 1 || dataFormatType > 4) {
				bReturn = false;
				System.out.println("Error: Data Format Type should be: 1, 2, 3 or 4 ");
				return bReturn;
			}

			return bReturn;
		} catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		}

	}

	private static void PrintInputRequirement() {

		System.out.println("=====================================================");
		System.out.println("Following Five (5) Parameters Required For Negative Sequential Pattern Mining");
		System.out.println("");
		System.out.println("parameter 1 : Algorithm type: ENSP, NGSP, PNSP"); // parameter
																				// 1
																				// :
																				// Algorithm
																				// type:
																				// ENSP,
																				// NGSP,
																				// PNSP
		System.out.println("parameter 2 : Source Data File"); // pparameter 2 :
																// Source Data
																// File
		System.out.println("parameter 3 : Source Data Format (1,2,3 or 4)"); // parameter
																				// 3
																				// :
																				// Source
																				// Data
																				// Format
		System.out.println("parameter 4 : Min_Sup (0.0 - 1.0"); // parameter 4 :
																// Min_Sup
		System.out.println("parameter 5 : Output File Name"); // parameter 5 :
																// Output File
																// Name

		System.out.println("");
		System.out.println(
				"i.e.: Java -Xmx1024M -jar NegSeq_Run.jar ENSP 1. C8_T4_S6_I6_DB100k_N0.1k.data 3 0.04 output_C8_T4_S6_I6_DB100k_N0.1k_0.04.txt");

		System.out.println("=====================================================");
	}

}
