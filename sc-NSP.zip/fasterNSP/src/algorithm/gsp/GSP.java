package algorithm.gsp;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;
import java.util.HashMap;

import sequence.*;
import sys.*;
import data.*;

/**
 * <title>GSP Algorithm Class</title>
 * core class, run gsp algorithm
 */

public class GSP {  
    private ArrayList<Sequence> c; //candidate set
    private ArrayList<Sequence> l; //sequence set
    private ArrayList<Sequence> lresult;  //save temp result;
    
    public SeqDB source_db;
    private double min_sup;
    private int support;
    private boolean negative = false;
    private ArrayList<SeqDB> pattern_db; //all sequences list
    
    private ArrayList<SequenceHash> hashs_PosPattern = new ArrayList<SequenceHash>();
    
    public logfile log;
    private long sumruntime=0;
    private long posruntime=0;
    private String SequenceCountString="";
    private int m_Neg_PatternCount;
    
    public boolean isDebug=false;
    
    private SequenceHash seqh = new SequenceHash();
	

   /**
    * 
    * @param support
    */
    public GSP(double min_sup) {
        this.min_sup = min_sup;                   
        this.source_db = new SeqDB();                    //get data from class SeqDB
        log = new logfile();
    }
    public GSP(double min_sup, String logfile) {
        this.min_sup = min_sup;                   
        this.source_db = new SeqDB();                    //get data from class SeqDB
        log = new logfile(logfile);
    }

    /**
     * Load training data from file, 
     * @param loadtype
     * @param datafilename
     */
    public boolean setdatasource(int loadtype,String filename){
    	if (source_db!=null){
    		source_db.loaddata(loadtype,filename);
    		return true;
    	}
    	else return false;
    }
    
    public void setdatasource(SeqDB sdb){
    	if (source_db!=null){
    		source_db = sdb;
    	} else {
    		source_db = new SeqDB(sdb.getSeqs());
    	}
    }
    
    /**
     * get all sequence set
     * core method, call join and prune method; then save to the result
     * @return sequence set
     */
    @SuppressWarnings("unchecked")
	public ArrayList getSequences(){
    	
    	this.support = (int) (this.min_sup * source_db.getSeqs().size());
    	
    	
    	long begin = System.currentTimeMillis();
    	getPosSequences();
    	long end = System.currentTimeMillis();
    	posruntime = end - begin;
    	if (negative==true) getNegSequences();    	
    	sumruntime = System.currentTimeMillis() - begin;    	
    	log.close();
    	return pattern_db;
    }
    
    /**
     * get all positive sequence set
     * core method, call join and prune method; then save to the result
     * @return sequence set
     */
    public ArrayList getPosSequences() {
        
    	long start = System.currentTimeMillis();
        pattern_db = new ArrayList<SeqDB>();
        
        initialize();
        System.out.println(l);
        SequenceCountString = SequenceCountString + "|+|0|" + l.size();
        for (Sequence s: l){
        	log.println(s.outputToString());//把l结果输出
        }  
        
        int i=0;
        while (l.size()>0){
            //generate candidate after join
            genCandidate();      
            if ( c.size() <= 0 ) {
                break;
            }     
            SequenceCountString = SequenceCountString + "|+|" + c.size();
            if (isDebug) log.println("before prune, pos candidate set is:["+c.size()+"] patterns, c is :"+c);
            pruneC();
            if (isDebug) log.println("after prune, pos candidate set is:["+c.size()+"] patterns, c is :"+c);
            //generate sequential patterns
            generateL();
            SequenceCountString = SequenceCountString + "|" + l.size();
            if (isDebug) log.println("pos sequential pattern L(" + (i + 2) + ") is: [" +l.size()+ "] patterns:" + l);
            addToResult(l);
            
            for (Sequence s: l){
            	log.println(s.outputToString());
            }            
            i++;
        }
        /*
        System.out.println("pattern_db = " + pattern_db.size()+ ",,");
        for (int j=0; j< pattern_db.size(); j++){
        	sdb = pattern_db.get(j);
        	System.out.println("sdb = " + sdb.size()+ ",,");
        	for (int k=0;k<sdb.getSeqs().size();k++){
        		Sequence s = sdb.getSeqs().get(k);
        		System.out.println("sdb222 = " + s.toString());
        	}
        }*/        
        long end = System.currentTimeMillis();
        log.println("running time is " + (end - start) + "ms!");

        return pattern_db;
    }

    /**
     * get all negative sequence set
     * core method, call join and prune method; then save to the result
     * @return sequence set
     */
    public ArrayList getNegSequences() {
        
    	long start = System.currentTimeMillis();
        
    	m_Neg_PatternCount = 0;
    	
        initializeNeg();        
        if (isDebug) log.println("neg sequence pattern L(1) is:[" +lresult.size()+ "] patterns: " + lresult); 
        SequenceCountString = SequenceCountString + " \n |-|0|" + lresult.size()
                              + "|";
        m_Neg_PatternCount += lresult.size();
        
        //for (Sequence s: lneg){
      int iflag=0;
        for (Sequence s: l){  //int i=0;
        	if (s.getSupport()>this.support)
        	log.println(s.outputToString());
        	//	log.println( iflag + "|" + s.outputToString() );
     		//iflag ++;
        	//i++;
        	//String (int)i;
        	//log.println(i);
        }      
                      
        int i=1;
        while (l.size()>0 || lresult.size()>0 ){
            //generate candidate after join        	
        	genNegCandidate(i-1);
        
        	if ( c.size() <= 0 )  break;
        	SequenceCountString = SequenceCountString + "||" + c.size()+"";
            //log.println("before prune,neg candidate set is:["+c.size()+"] patterns, c is :"+c);
            pruneCNeg();
            SequenceCountString = SequenceCountString + "|" + c.size()+"";
           // log.println("after prune, neg candidate set is:["+c.size()+"] patterns, c is :"+c);
            //generate sequential patterns
            generateLNeg();
            pruneCNeg_Seedset();
            //log.println("l.size=" + l.size());            
            //if (( PruneType ==2 || PruneType==1 ) && i>=2) afterPrune();
            //log.println("afterprune: l.size=" + l.size());
            
            /*if (lresult.size()>0){
            	if (i<pattern_db.size()){
                	for (Sequence s: lresult){
                		pattern_db.get(i).getSeqs().add(s);            
                	}
                }else{
                	SeqDB sdb = new SeqDB(lresult);
                	pattern_db.add(sdb);
                }
            }*/

            //log.println("negative sequential pattern l is: [" +l.size()+ "] patterns:" + l);
            //log.println("negative sequential pattern Lresult is: [" +lresult.size()+ "]");
            SequenceCountString = SequenceCountString + "|" + lresult.size() 
			                      + "|";

          //  int iflag = 0;
            for (Sequence s: lresult){
            	//log.println(s.outputToString()); 
            	log.println( iflag + "|" + s.outputToString() );
         		iflag ++;
            }     
            
            m_Neg_PatternCount += lresult.size();
            
            i++;
        }           
        long end = System.currentTimeMillis();
        log.println("running time is " + (end - start) + "ms!");
        log.close();
        
        //return this.result;
        return pattern_db;
    }

    /*
     * initial method
     */
    private void initialize() {

        Map<Integer, Integer> can1 = new HashMap<Integer, Integer>();
        Map<Integer, Integer> can = new HashMap<Integer, Integer>();
        Map<Integer, Integer> arr;

        //all positive 1-item set
        for (Sequence s : source_db.getSeqs()) {
            //for all sequence in data set
        	arr = new HashMap<Integer, Integer>();
            for (Element e : s.getElements()) {
                //for all elements in sequence
                for (int i : e.getItems()) {
                    arr.put(i,i);
                    if(i==1){
                    	System.out.println("s:  "+s);
                    }
                    
                }
            }
            for (int i: arr.values()){
            	if (can.containsKey(i)) {
                    int count = can.get(i).intValue() + 1;
                    can.put(i, count);
                } else {
                    can.put(i, 1);
                }
            }        	
        }
        
        this.l = new ArrayList<Sequence>();

        //for all candidate set, if greater than min support, 
        //then add it into sequential pattern set L
        for (int i : can.keySet()) {
        	int ivalue = can.get(i).intValue();        	
        	if ( i > 0 && ivalue > support ) { //positive pattern
                Element e = new Element(new int[] {i});
                Sequence seq = new Sequence();
                seq.addElement(e);
                seq.setSupport(ivalue);
                this.l.add(seq);
                //log.println(seq.toString() + " support = " +ivalue);
            }
        }

        //add to result set
        this.addToResult(l);
        
    }
    
    /*
     * initial negative item method
     */
    private void initializeNeg() {

        //all positive sequence transform to negative sequence
    	SeqDB sdb;
    	this.l = new ArrayList<Sequence>();
    	
    	//save to hash table
     	
     	for (int i=0; i<pattern_db.size(); i++){
     		SequenceHash hs = new SequenceHash();
     		for (int j=0; j<pattern_db.get(i).getSeqs().size();j++){
     			Sequence s1 = pattern_db.get(i).getSeqs().get(j);
     			hs.put(s1);
     		}
     		hashs_PosPattern.add(hs);
     	}
     	
    	//for (int j=0; j< pattern_db.size(); j++){
    	for (int j=0; j< 1; j++){
        	sdb = pattern_db.get(j);
        	for (int k=0;k<sdb.getSeqs().size();k++){
        		Sequence s = sdb.getSeqs().get(k);
        		Sequence news = new Sequence();    
        		Element e = s.getElement(0);
        		int[] a = {-e.getItem(0)};
        		Element newe = new Element(a);
        		news.addElement(newe);
        		l.add(news);
        	}        	
        }
    	  	
    	//add to result set
    	if (lresult==null)  lresult = new ArrayList<Sequence>();
    	
    	for (Sequence s:l){
    		Sequence news = new Sequence(s);
    		lresult.add(news);
    		pattern_db.get(0).getSeqs().add(new Sequence(news));
    	}
    }
    
    /*
     * generate candidate set by join operation
     */
    private void genCandidate() {

        this.c = new ArrayList<Sequence>();
        
        seqh.getHashTable().clear();
        
        //join among sequential pattern set L
        for (int i = 0; i < this.l.size(); i++) {
            for (int j = i; j < this.l.size(); j++) {
            	this.joinAndInsert(l.get(i), l.get(j));
                if (i != j) {
                    this.joinAndInsert(l.get(j), l.get(i));  
                }
            }
        }
    }

    /*
     * generate negative candidate set by join operation
     */
    private void genNegCandidate(int index) {

        this.c = new ArrayList<Sequence>();
        //this.l = new ArrayList<Sequence>();
                
        seqh.getHashTable().clear();
        //if (index==0) l.clear();
        
        ArrayList<Sequence> lpos = new ArrayList<Sequence>();   // all positive     
        if (index<pattern_db.size()){
        	for (Sequence s: pattern_db.get(index).getSeqs()){
        		lpos.add(new Sequence(s));
        	}
        }
        
        // add element with more than 1-item
        
        if ( (index+1)<pattern_db.size()){
        	for (Sequence s: pattern_db.get(index+1).getSeqs()){
        		if (s.size()==1){
        			Sequence sneg = new Sequence(s.getNegativeSequence());
        			if(!sneg.isInSeqs(seqh)) { 
        				c.add(sneg);
        				seqh.put(sneg);
        				//l.add(sneg);
        			}
        		}
        	}
        }
        
        
        //join among sequential pattern set L
        
        // + join -
        for (int i = 0; i < lpos.size(); i++) {
            for (int j = 0; j < this.l.size(); j++) {
            	this.joinAndInsertNeg(lpos.get(i), l.get(j));
                this.joinAndInsertNeg(l.get(j), lpos.get(i));
            }
        }
        
        //- join -
        for (int i = 0; i < this.l.size(); i++) {
            for (int j = i; j < this.l.size(); j++) {
            	
            	this.joinAndInsertNeg(l.get(i), l.get(j));
                this.joinAndInsertNeg(l.get(j), l.get(i));
            }
        }
        //log.println("candidate: c = " + c.toString());         
    }

   /*
    * Join method between two sequence
    */
    private void joinAndInsert(Sequence s1, Sequence s2){
    
    	
    	Sequence s, st;
        //remove first element
        Element ef = s1.getElement(0).getWithoutFistItem(); 
        //remove last element
        Element ee = s2.getElement(s2.size() - 1).getWithoutLastItem();
        
        int i = 0, j = 0;
        if (ef.size() == 0) {
            i++;
        }
        for (; i < s1.size() && j < s2.size(); i++, j++) {
            Element e1, e2;
            if (i == 0) {
                e1 = ef;
            } else {
                e1 = s1.getElement(i);
            }
            if (j == s2.size() - 1) {
                e2 = ee;
            } else {
                e2 = s2.getElement(j);
            }
            if (!e1.equalsTo(e2)) {
                return;
            }
        }
        
       
        if (s1.size()==1 || s2.getElement(s2.size()-1).size()>1) {
        	//add the last item of s2 into s
            s = new Sequence(s1);
            int slast = s.getElement(s.size() - 1).getLastItem();
            int s2last = s2.getElement(s2.size()-1).getLastItem();
            if (slast>0 && s2last > 0 && slast!=s2last) {
             	(s.getElement(s.size() - 1)).addItem(s2last);
             	//log.print("S1=" + s1.toString() + "=s2=" + s2.toString());
            	//log.println("=s=" + s.toString());
            	if (!s.isInSeqs(seqh)) { 
                	c.add(s);
                	seqh.put(s);
                }
            }    
        }
        
        if (s1.size()==1 || s2.getElement(s2.size()-1).size()==1) {
        	//add the last element of s2 into s        
            st = new Sequence(s1);
            int s2end = s2.getElement(s2.size()-1).getLastItem();
            st.addElement(new Element(new int[] {s2end}));
            //log.print("S1=" + s1.toString() + "=s2=" + s2.toString());
        	//log.println("=st=" + st.toString());
            if (!st.isInSeqs(seqh) ){
            	c.add(st); 
        	    seqh.put(st);
            }
        }
        
    }

    /*
     * Join method between two sequence
     */
     private void joinAndInsertNeg(Sequence s1, Sequence s2){
    	 
    	 if (s1.toString().equals("<1 -12>") && s2.toString().equals("<(-12,-114)>")){
     		int iiii;
     		iiii=0;
     	}
     	
     
     	Sequence s, st;
         //remove first element
         Element ef = s1.getElement(0).getWithoutFistItem(); 
         //remove last element
         Element ee = s2.getElement(s2.size() - 1).getWithoutLastItem();
         
         int i = 0, j = 0;
         if (ef.size() == 0) {
             i++;
         }
         for (; i < s1.size() && j < s2.size(); i++, j++) {
             Element e1, e2;
             if (i == 0) {
                 e1 = ef;
             } else {
                 e1 = s1.getElement(i);
             }
             if (j == s2.size() - 1) {
                 e2 = ee;
             } else {
                 e2 = s2.getElement(j);
             }
             if (!e1.equalsTo(e2)) {
                 return;
             }
         }
         
         ///*
         if (s1.size()==1 || s2.getElement(s2.size()-1).size()>1) {
        	 s = new Sequence(s1);
             //add the last item of s2 into s   
             int slast = s.getElement(s.size() - 1).getLastItem();
             int s2last = s2.getElement(s2.size()-1).getLastItem();
             //if (slast>0 && s2last > 0 && slast!=s2last) {
             //if (slast>0 && s2last > 0 ) {
             if (slast!=s2last){
             	(s.getElement(s.size() - 1)).addItem(s2last);
             	if (!s.isInSeqs(seqh)) { 
                 	c.add(s);
                 	seqh.put(s);
                 }
             }// */             
         }
         
         if (s1.size()==1 || s2.getElement(s2.size()-1).size()==1) {
        	 st = new Sequence(s1);
             //add the last element of s2 into s        
             Element ele = s2.getElement(s2.size()-1);
             int s2end = ele.getLastItem();
             st.addElement(new Element(new int[] {s2end}));
             if (!st.hasTwoNeg() && !st.isInSeqs(seqh) ){
             	c.add(st); 
         	    seqh.put(st);
             }             
         }
     }
    /*
     * Prune Operation
     * verify whether every continuous sub sequence of candidate set is frequent
     * get element one by one, remove one element, to see whether sub sequence is in L
     */
    private void pruneC() {
        Sequence s;
        
        SequenceHash lhash = new SequenceHash();       	
        for (Sequence stemp: l){
        	lhash.put(stemp);
        } 
        
        //for all element in sequence
        for (int i = 0; i < this.c.size();i++) {
            s = c.get(i);
            boolean is = false;
            //for all items in element
            for (int j = 0; j < s.size(); j++) {
                Element ce = s.getElement(j);
                boolean prune=false;
                //only one element
                if (ce.size() == 1) {
                    s.removeElement(j);
                    //if sub sequence is not frequent, then remove it from candidate set, 
                    // otherwise add it into candidate set
                    if (!s.isInSeqs(lhash)) {   
                        prune=true;                        
                    }
                    s.insertElement(j, ce);
                } else {
                    for (int k = 0; k < ce.size(); k++) {
                        
                    	int item=ce.removeItem(k);
                        //if sub sequence is not frequent, then remove it from candidate set, 
                        // otherwise add it into candidate set
                        if (!s.isInSeqs(lhash)) {
                            prune=true;
                        }
                        ce.addItem(item); 
                    }
                }

                //if prune, then remove the sequence
                if(prune){
                    c.remove(i);
                    i--;
                    break;
                }
            }
        } 
    }


    /*
     * Negative candidates Prune Operation
     * verify whether every continuous sub sequence of candidate set is frequent
     * get element one by one, remove one element, to see whether sub sequence is in L
     */
    private void pruneCNeg() {
        
    	Sequence s;
    	int MaxLength = pattern_db.size();
    	
     	
        //for all element in sequence
         
    	for (int i = 0; i < this.c.size();i++) {
            s = c.get(i);
            boolean prune = false;
            
            /*
            //Sequence pos = s.getPosFromSeq();
            
            int possize = 0;
            for (int j=0; j< pos.size(); j++){
            	possize = possize + pos.getElement(j).size();
            }
            if ( possize>0 && !pos.isInSeqs(hashs.get(possize-1))){
            	prune = true;
            }*/
            
            if (s.size()>MaxLength) prune = true;
            
            Sequence ce = s.getCounterExample(); 
            if (prune==false && !ce.isInSeqs(hashs_PosPattern.get(ce.itemsize()-1))){
            	prune = true;
            }
            
            //if prune, then remove the sequence
            if(prune){
                c.remove(i);
                i--;
            }
        }         
    }
    
    private void pruneCNeg_Seedset() {
        
    	Sequence s;
    	int MaxLength = pattern_db.size();
    	
     	//save to hash table
     	/*ArrayList<SequenceHash> hashs = new ArrayList<SequenceHash>();
     	for (int i=0; i<pattern_db.size(); i++){
     		SequenceHash hs = new SequenceHash();
     		for (int j=0; j<pattern_db.get(i).getSeqs().size();j++){
     			Sequence s1 = pattern_db.get(i).getSeqs().get(j);
     			hs.put(s1);
     		}
     		hashs.add(hs);
     	}*/
        //for all element in sequence
         
    	for (int i = 0; i < this.l.size();i++) {
            s = l.get(i);
            boolean prune = false;
            
            /*
            //Sequence pos = s.getPosFromSeq();
            
            int possize = 0;
            for (int j=0; j< pos.size(); j++){
            	possize = possize + pos.getElement(j).size();
            }
            if ( possize>0 && !pos.isInSeqs(hashs.get(possize-1))){
            	prune = true;
            }*/
            
            if (s.size()>MaxLength) prune = true;
            
            Sequence ce = s.getCounterExample(); 
            if (prune==false && !ce.isInSeqs(hashs_PosPattern.get(ce.itemsize()-1))){
            	prune = true;
            }
            
            //if prune, then remove the sequence
            if(prune){
                l.remove(i);
                i--;
            }
        }         
    }
   
   
    /*
     * generate sequential pattern set L
     * after join and prune, get the data set
     */
    private void generateL() {
    	l.clear();
        this.l = new ArrayList<Sequence>();
        for (Sequence s : source_db.getSeqs()) {
            for (Sequence seq : this.c) {
            	if (seq.isMatch(s)) {
            		//count support
            		seq.incrementSupport();            		
            	}
            }
        }
        for (Sequence seq : this.c) {
            //if greater than min support, then add to sequential pattern set        	
            if (seq.getSupport() > this.support) {
                this.l.add(seq);
            }
        }
    }
    
    /*
     * generate sequential pattern set L
     * after join and prune, get the data set
     */
    private void generateLNeg() {
    	l.clear();
    	if (lresult==null) lresult = new ArrayList<Sequence>();
    	else lresult.clear();
    	
        this.l = new ArrayList<Sequence>();
        
        for (Sequence seq : this.c) {
        	seq.setCover(0);
        	seq.setSupport(0);
        }
        
        for (Sequence s : source_db.getSeqs()) {
        	for (Sequence seq : this.c) {
            	//if (seq.isMatch(s)) {        //n-cover
        		if (seq.isNInclude(s)) {        //n-cover
            		seq.incrementCover();
            		//if (!seq.getCounterExample().isMatch(s)){ //n-contain
            		//if (seq.isNCover(s)){ //n-contain
            		//if (seq.isNContain(s)){ //n-contain
            		if (seq.isXJNegMatch(s)){
            			seq.incrementSupport();
            		}
            	}
            }
        }
        for (Sequence seq : this.c) {
            //if greater than min support, then add to sequential pattern set
            if (seq.getSupport() > this.support){
         	   lresult.add(seq);
         	   Sequence s = new Sequence(seq);
         	   s.setSupport(seq.getSupport());
         	   s.setCover(seq.getCover());
         	   this.l.add(s);
            } else {
         	   //if (seq.getElement(seq.size()-1).getFirstItem()<0 && seq.getCover()>this.support){
         	   if (seq.getCover()>this.support){
         		   this.l.add(seq);
         	   }
            }
            // }
         }
    }

    /*
     * add the frequent sequence pattern into result set
     */
    private void addToResult(ArrayList<Sequence> l) { 
        
    	pattern_db.add(new SeqDB(l));
    }

    /**
     * output the sequential pattern
     */
   public void outputInput() {
          log.println("support is: " + this.support);
          log.println("");
   }
   
   /**
    * set algorithm type, whether it can do negative sequence mining
    */
   public void setNegative(boolean isNeg){
	   this.negative = isNeg;
   }
   
   public long getSumRuntime(){
	   return sumruntime;
   }
   
   public long getPosRuntime(){
	   return posruntime;
   }

   public String getSequenceCountString(){
	   return SequenceCountString;
   }
   
   public int getPatternsCount(){
	   
	   return m_Neg_PatternCount;
   }
}

