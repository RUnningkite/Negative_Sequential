package algorithm.presnsp;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collection;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;



import java.util.HashMap;
import java.util.HashSet;

import sequence.*;
import sys.*;
import data.*;

/**
 * <title>faster Algorithm Class</title>
 * core class, run faster algorithm
 */

public class PreNsp {  
    private ArrayList<Sequence> c; //candidate set
    private ArrayList<Sequence> l; //sequence set

    private ArrayList<Sequence> neglist;
    private ArrayList<Sequence> lresult;  //save temp result;
    private ArrayList<SequentialPattern> ll;
    private ArrayList<SequentialPattern> tr;
    public SeqDB source_db;
    private double min_sup;
    
 // maximum pattern length in terms of item count
 	private int maximumPatternLength = Integer.MAX_VALUE;
    private int maxlength;
    private int memory=0;
    private int support;
    private int patternCount;
    
    private int max = 0;
    private int avg=0;
    private int sidcount=0;
    private boolean negative = false;
    private ArrayList<SeqDB> pattern_db; //all sequences list
    private ArrayList<SeqDB> pattern_db_neg; //all sequences list
    private ArrayList<Sequence> l1item;
    
    public logfile log;
    private long sumruntime=0;
    private long posruntime=0;
    private long NSCsum=0;
    private String SequenceCountString="";
    
    private SequenceHash seqh = new SequenceHash();
    private ArrayList<Hashtable> IDList;
    private ArrayList<HashMap> SetIDList;
    private ArrayList<Sequence> OnePsp;
	
    public boolean isDebug = false;

   /**
    * 
    * @param support
    */
    public PreNsp(double min_sup) {
        this.min_sup = min_sup;                   
        this.source_db = new SeqDB();                    //get data from class SeqDB
        log = new logfile();
        SetIDList = new ArrayList<HashMap>();
        IDList = new ArrayList<Hashtable>();
         tr =new ArrayList<SequentialPattern>();
         OnePsp = new ArrayList<Sequence>(); 
    }
    public PreNsp(double min_sup, String logfile) {
        this.min_sup = min_sup;                   
        this.source_db = new SeqDB();                    //get data from class SeqDB
        log = new logfile(logfile);
        SetIDList = new ArrayList<HashMap>();
        IDList = new ArrayList<Hashtable>();
        tr =new ArrayList<SequentialPattern>();
        OnePsp = new ArrayList<Sequence>(); 
    }

    /**
     * Load training data from file, 
     * @param loadtype
     * @param datafilename
     */
    public boolean setdatasource(int loadtype,String filename){
    	//System.out.println("qqqqqq");
    	if (source_db!=null){
    		source_db.loaddata(loadtype,filename);
    		System.out.println(source_db.size());
    		return true;
    		
    	}
    	else return false;
    }
    
    public void setdatasource(SeqDB sdb){
    	if (source_db!=null){
    		source_db = sdb;
    	} else {
    		source_db = new SeqDB(sdb.getSeqs());
    	}
    }

    
    /**
     * get all positive sequence set
     * core method, call join and prune method; then save to the result
     * @return sequence set
     * @throws IOException 
     */
    public ArrayList getSequences() throws IOException {
    	patternCount = 0;
    	long start = System.currentTimeMillis();
    	Runtime run = Runtime.getRuntime();
    	run.gc();
    	System.out.println("time: " + (new Date()));
    	long startMem = run.totalMemory()-run.freeMemory();
    	long i = run.freeMemory();
    	System.out.println("memory> total:" + run.totalMemory() + " free:" + run.freeMemory() + " used:" + startMem );
    	//Runtime.getRuntime().gc();
    	//Thread.yield();
    	//Long i = Runtime.getRuntime().freeMemory();
    	//System.out.println(i);
    	//long start = System.nanoTime();
        pattern_db = new ArrayList<SeqDB>();
        pattern_db_neg = new ArrayList<SeqDB>();
        
        this.support = (int) (this.min_sup * source_db.getSeqs().size());
        System.out.println("support"+support);
       
        prefixSpan(source_db);
        long end = System.currentTimeMillis();
        //long end = System.nanoTime();
        posruntime = end - start;
        log.println("running time is " + (end - start) + "ms!");
        classification();
       // addToResult(l);
       
        System.out.println("正序列结束");

        getNegSequences();                
        end = System.currentTimeMillis();
       // end = System.nanoTime();
        sumruntime = end - start;
        
       // Runtime.getRuntime().gc();
      //  Thread.yield();
     //  Long j = Runtime.getRuntime().freeMemory();
     //  System.out.println(j);
     //   System.out.println(i-j);
        System.out.println("time: " + (new Date()));
        long endMem = run.totalMemory()-run.freeMemory();
        long j = run.freeMemory();
        System.out.println("memory> total:" + run.totalMemory() + " free:" + run.freeMemory() + " used:" + endMem );
        System.out.println("memory difference:" + (endMem-startMem));
        System.out.println("memory i-j:" + (i-j));
        log.println("running time is " + (end - start) + "ms!");
        return pattern_db;
    }
    
    public void getNegSequences() {
    	
    	long start = System.nanoTime();
    	initializeNeg();
    	genNegoneCandidate();
    	//System.out.println("max"+maxlength);
    	//System.out.println("max"+lneg);
    	int i = 2;
    	int a = 2*max+1;
    	System.out.println("max"+a);
    	while(i<a && this.c.size() !=0){
    		System.out.println("length"+i);
    		
    	//	System.out.println(pattern_db.get(i).getSeqs());
    		//System.out.println("--------------"+i);
    	generNeg(pattern_db.get(i-1));
       //addToResultNeg(neg1);
       i++;
    	}
    	//System.out.println("3333\\"+pattern_db);
    	
    	// for (int j=0; j< pattern_db.size(); j++){
    	// System.out.println("tt"+j);
         //	SeqDB sdb = pattern_db.get(j);
         //	ArrayList<Sequence> l = sdb.getSeqs();
         	
         	//System.out.println("pp"+l);
         	//ArrayList<Sequence> lneg = new ArrayList<Sequence>();
          //  lneg = generateLNeg(l);
         //   System.out.println(lneg);
          //  addToResultNeg(lneg);         	
        // }
    	
    	 int iflag = 0;
         for (int j=0; j< pattern_db_neg.size(); j++){
        	
         	SeqDB sdb = pattern_db_neg.get(j);
         	//System.out.println("sdb = " + sdb.size()+ ",,");
         	for (int k=0;k<sdb.getSeqs().size();k++){
         		Sequence s = sdb.getSeqs().get(k);
         		log.println( iflag + "|" + s.outputToString() );
         		iflag ++;
         	}         	
         }    
       
         long end = System.nanoTime();
         log.println("running time is " + (end - start) + "ms!");
    }

 
    private void prefixSpan(SeqDB database) throws IOException{
    	// We have to scan the database to find all frequent sequential patterns of size 1.
    	// We note the sequences in which the items appear.注意项出现的顺序
    	//System.out.println("---------2---");
    	HashMap<Integer,Set<Integer>> mapSequenceID = findSequencesContainingItems(database);
    	System.out.println(database.size());
    	//for(Integer a : mapSequenceID.keySet()){
    	//	System.out.println(a+" : "+ mapSequenceID.get(a));
    	//}
    	// WE CONVERT THE DATABASE ITON A PSEUDO-DATABASE, AND REMOVE
    	// THE ITEMS OF SIZE 1 THAT ARE NOT FREQUENT, SO THAT THE ALGORITHM 
    	// WILL NOT CONSIDER THEM ANYMORE. 
    	
    	// Create a list of pseudosequence伪序列，这里就需要开始加上id了(need add id)
    	ArrayList<PseudoSequence> initialDatabase = new ArrayList<PseudoSequence>();
    	// for each sequence in  the database
    	for(Sequence sequence : database.getSeqs()){
    		//System.out.println("---------2---"+sequence);
    		// remove infrequent items 删去非频繁的项
    		Sequence optimizedSequence = sequence.cloneSequenceMinusItems(mapSequenceID, support);
    		//System.out.println("---------2---"+optimizedSequence);
    		if(optimizedSequence.size() != 0){
    			// if the size is > 0, create a pseudo sequence with this sequence
    			initialDatabase.add(new PseudoSequence(optimizedSequence, 0, 0));
    			
    		}
    		
    	}
    	//Iterator<PseudoSequence> it = initialDatabase.iterator();
    	//while(it.hasNext()){
    	//	PseudoSequence s = it.next();
    	//	System.out.println("--"+s.getSeq());
    	//}
    	//System.out.println("initialDatabase"+initialDatabase);
    	
    	
    	//已删完非频繁的项
    	// For each item
    	for(Entry<Integer, Set<Integer>> entry : mapSequenceID.entrySet()){
    		 //if the item is frequent  (has a support >= minsup)
    		if(entry.getValue().size() > support){
    			Integer item = entry.getKey();
    			
    			// Create the prefix for this projected database 为投影数据库创建前缀
    			SequentialPattern prefix = new SequentialPattern(); //前缀的序列号 
    			Element e = new Element();
    			e.addItem(item);
    			prefix.addItemset(e);
				prefix.setSequenceIDs(entry.getValue());
				
				//System.out.println("prefix"+prefix.getItemsets());
				// The prefix is a frequent sequential pattern.
				// We save it in the result.
				savePattern(prefix);
				
				// build the projected database for that item 为该项构建投影数据库
				//initialDatabase 是存放频繁的序列的
				ArrayList<PseudoSequence> projectedContext 
				= buildProjectedDatabaseForSingleItem(item, initialDatabase, entry.getValue());
				//System.out.println("projectedContext"+projectedContext);
				//System.out.println(item);
				//Iterator<PseudoSequence> iit = projectedContext.iterator();
				//while(iit.hasNext()){
				//	PseudoSequence s = iit.next();
				//System.out.println("-------"+s.getSeq()+", "+ s.getFirstItemset()+", "+s.getFirstItem());
				//}
				// We make a recursive call to try to find larger sequential
				// patterns starting with this prefix
				
				if(maximumPatternLength >1){
					recursion(prefix, projectedContext, 2); 
				}
    		}
    		
    	}
    	
    	
    	
    }
    
    /**
	 * Create a projected database by pseudo-projection with the initial database and a given item.
	 * @param item The item to use to make the pseudo-projection
	 * @param initialDatabase The current database.
	 * @param sidSet  The set of sequence ids containing the item
	 * @return the projected database.
	 */
    
    private ArrayList<PseudoSequence> buildProjectedDatabaseForSingleItem(Integer item, ArrayList<PseudoSequence> initialDatabase,Set<Integer> sidSet){
    	// We create a new projected database
    	ArrayList<PseudoSequence> sequenceDatabase = new ArrayList<PseudoSequence>();
    	
    	// for each sequence in the database received as parameter
    	for(PseudoSequence sequence : initialDatabase){ 
    		// if this sequence do not contain the current prefix, then skip it.
    					if(!sidSet.contains(sequence.getId())){//这里带着id
    						continue;
    					}
    					//System.out.println("++++++"+sequence.getSeq());
    					// for each itemset of the sequence
        				for(int i = 0; i< sequence.size(); i++){
        					
        					// check if the itemset contains the item that is used for the projection检查项目集是否包含用于投影的项目
        					int index = sequence.indexOfBis(i, item);//item-频繁的项
        					// if it does not, and the current item is part of a suffix if inSuffix is true
        					//   and vice-versa
        					if(index == -1 ){
        						continue;
        					}
        					
        					// if the item is the last item of this itemset
            				if(index == sequence.getSizeOfItemsetAt(i)-1){ 
            					// if it is not the last itemset
            					if ((i != sequence.size()-1)){
            						// create new pseudo sequence
            						// add it to the projected database.
            						sequenceDatabase.add(new PseudoSequence( sequence, i+1, 0));
            					}
        				}else{
        					// create a new pseudo sequence and
        					// add it to the projected database.
        					sequenceDatabase.add(new PseudoSequence(sequence, i, index+1));
        				}
        				//System.out.println("------"+sequence.getSeq());
        				}
    	}
    	
    	
    	//for(PseudoSequence seq : sequenceDatabase){
//			System.out.println(seq);
//			System.out.println("original seq: " + seq.sequence);
//		}
    	//Iterator<PseudoSequence> it = sequenceDatabase.iterator();
    	//while(it.hasNext()){
    	//	PseudoSequence s = it.next();
    	//	System.out.println("-------"+s.getSeq());
    	//}
		
    	return sequenceDatabase; // return the projected database
    }
    
    /**
	 * Method to recursively grow a given sequential pattern.
	 * @param prefix  the current sequential pattern that we want to try to grow
	 * @param database the current projected sequence database
	 * @param k  the prefix length in terms of items
	 * @throws IOException exception if there is an error writing to the output file
	 */
    private void recursion(SequentialPattern prefix, ArrayList<PseudoSequence> database, int k) throws IOException {
    	// find frequent items of size 1 in the current projected database.  //di gui jian ku
    	Set<Pair> pairs = findAllFrequentPairs(database);
    	//System.out.println(prefix);
		//Iterator<Pair> it = pairs.iterator();
		//while(it.hasNext()){
		//	Pair s = it.next();
		//	System.out.println("-------"+s.getItem()+","+s.getSequenceIDs());
		//}
    	// For each pair found (a pair is an item with a boolean indicating if it
    	// appears in an itemset that is cut (a postfix) or not, and the sequence IDs
    	// where it appears in the projected database).
    	for(Pair pair : pairs){
    		// if the item is frequent in the current projected database
    		if(pair.getCount() > support){
    			// create the new postfix by appending this item to the prefix
				SequentialPattern newPrefix;
				// if the item is part of a postfix
				if(pair.isPostfix()){ 
					// we append it to the last itemset of the prefix
					newPrefix = appendItemToPrefixOfSequence(prefix, pair.getItem()); 
				}else{ // else, we append it as a new itemset to the sequence
					newPrefix = appendItemToSequence(prefix, pair.getItem());
				}
				newPrefix.setSequenceIDs(pair.getSequenceIDs());
				
				// build the projected database with this item
				ArrayList<PseudoSequence> projectedDatabase = buildProjectedDatabase(pair.getItem(), database, pair.getSequenceIDs(), pair.isPostfix());
				
				// save the pattern
				savePattern(newPrefix);
				// make a recursive call
				if( k < maximumPatternLength){
					recursion(newPrefix, projectedDatabase, k+1);
				}
    		}
    	}
    }
    
    /**
	 * Create a projected database by pseudo-projection
	 * @param item The item to use to make the pseudo-projection
	 * @param database The current sequence database.
	 * @param inPostFix This boolean indicates if the item "item" is part of a suffix or not.
	 * @param sidset the set of sequence IDs of sequence containing this item
	 * @return the projected database.ll
	 */
    private ArrayList<PseudoSequence> buildProjectedDatabase(Integer item, List<PseudoSequence> database, Set<Integer> sidset, boolean inPostFix) {
    	// We create a new projected database
    	ArrayList<PseudoSequence> sequenceDatabase = new ArrayList<PseudoSequence>();
    	
    	// for each sequence in the database received as parameter
    	for(PseudoSequence sequence : database){ 
    		
    		if(sidset.contains(sequence.getId()) == false){
				continue;
			}
    		
    		// for each itemset of the sequence
    		for(int i = 0; i< sequence.size(); i++){
    				
    			if (sequence.isPostfix(i) != inPostFix){
					// if the item is not in a postfix, but this itemset
					// is a postfix, then we can continue scanning from the next itemset
					continue;
				}
    			
    			// check if the itemset contains the item that we use for the projection
				int index = sequence.indexOfBis(i, item);
				
				// if it does not, move to next itemset
				if(index == -1 ){
					continue;
				}
				// if the item is the last item of this itemset
				if(index == sequence.getSizeOfItemsetAt(i)-1){ 
					// if it is not the last itemset
					if ((i != sequence.size()-1)){
						// create new pseudo sequence
						// add it to the projected database.
						sequenceDatabase.add(new PseudoSequence( sequence, i+1, 0));
						//System.out.println(sequence.getId() + "--> "+ newSequence.toString());
//						break itemsetLoop;
					}
				}else{
					// create a new pseudo sequence and
					// add it to the projected database.
					sequenceDatabase.add(new PseudoSequence(sequence, i, index+1));
					//System.out.println(sequence.getId() + "--> "+ newSequence.toString());
//					break itemsetLoop;
				}
				
    		}
    	}
    	return sequenceDatabase;// return the projected database
    	
    }
    
    /**
	 *  This method creates a copy of the sequence and add a given item 
	 *  as a new itemset to the sequence. 
	 *  It sets the support of the sequence as the support of the item.
	 * @param prefix  the sequence
	 * @param item the item
	 * @return the new sequence
	 */
	private SequentialPattern appendItemToSequence(SequentialPattern prefix, Integer item) {
		SequentialPattern newPrefix = prefix.cloneSequence();  // isSuffix
		Element e = new Element();
		e.addItem(item);
		newPrefix.addItemset(e);  // cr�� un nouvel itemset   + decalage
		return newPrefix;
	}
    
    /**
	 *  This method creates a copy of the sequence and add a given item 
	 *  to the last itemset of the sequence. 
	 *  It sets the support of the sequence as the support of the item.
	 * @param prefix  the sequence
	 * @param item the item
	 * @return the new sequence
	 */
    private SequentialPattern appendItemToPrefixOfSequence(SequentialPattern prefix, Integer item) {
		SequentialPattern newPrefix = prefix.cloneSequence();
		Element itemset = newPrefix.get(newPrefix.size()-1);  // ajoute au dernier itemset
		itemset.addItem(item);  
		return newPrefix;
	}
    
    /**
	 * Method to find all frequent items in a projected sequence database
	 * @param sequences  the set of sequences
	 * @return A list of pairs, where a pair is an item with (1) a boolean indicating if it
	 *         is in an itemset that is "cut" and (2) the sequence IDs where it occurs.
	 *            对的列表，其中一对是具有（1）布尔值的项目，指示它是否在被“剪切”的项目集中，以及（2）其出现的序列ID。
	 */
    protected Set<Pair> findAllFrequentPairs(List<PseudoSequence> sequences){
    	// We use a Map the store the pairs.
    	Map<Pair, Pair> mapPairs = new HashMap<Pair, Pair>();   
    	// for each sequence
    	for(PseudoSequence sequence : sequences){
    		// for each itemset
			//System.out.println("sequence"+sequence.getSeq());
    		for(int i=0; i< sequence.size(); i++){
    			// for each item
				for(int j=0; j < sequence.getSizeOfItemsetAt(i); j++){
					Integer item = sequence.getItemAtInItemsetAt(j, i);
					//System.out.println("item"+item);
					//System.out.println("isPostfix"+sequence.isPostfix(i));
					// create the pair corresponding to this item
					Pair pair = new Pair(sequence.isPostfix(i), item);   
					// get the pair object store in the map if there is one already
					Pair oldPair = mapPairs.get(pair);
					// if there is no pair object yet
					if(oldPair == null){
						// store the pair object that we created
						mapPairs.put(pair, pair);
					}else{
						// otherwise use the old one
						pair = oldPair;
					}
					// record the current sequence id for that pair
					pair.getSequenceIDs().add(sequence.getId());
				}
    						
    		}
    	}
    	//MemoryLogger.getInstance().checkMemory();  // check the memory for statistics.
		// return the map of pairs
		return mapPairs.keySet();
    	
    }
    
    /**
	 * This method saves a sequential pattern to the output file or
	 * in memory, depending on if the user provided an output file path or not
	 * when he launched the algorithm
	 * @param prefix the pattern to be saved.
	 * @throws IOException exception if error while writing the output file.
	 */
    
    private void savePattern(SequentialPattern prefix) throws IOException {
    	int i;
    	patternCount++;
    	//System.out.println(prefix);
    	log.println( patternCount + "|" + prefix.toString()+ ":"+ prefix.getidlist().size() );
     	tr.add(prefix);
     	
    	
    }
    
    private HashMap<Integer,Set<Integer>> findSequencesContainingItems(SeqDB database){
    	// We use a map to store the sequence IDs where an item appear
    	// Key : item   Value :  a set of sequence IDs
    	HashMap<Integer,Set<Integer>> mapSequenceID = new HashMap<Integer,Set<Integer>>();
    	maxlength = 0;
    	// for each sequence in the current database
    	for(Sequence s : database.getSeqs()){
    		//for each element
    		//log.print(s.outputToString());
    		//System.out.println("s"+s);
    		if(s.size()>maxlength){
    			maxlength = s.size();
    		}
    		for(Element e : s.getElements()){
    			
    			for (int item : e.getItems()){
    				//System.out.println(item);
    				Set<Integer> sequenceIDs = mapSequenceID.get(item);
    				//System.out.println("mapSequenceID"+mapSequenceID.get(item));
    				if(sequenceIDs == null){
    					sequenceIDs = new HashSet<Integer>();
    					mapSequenceID.put(item, sequenceIDs);
    				}
    				sequenceIDs.add(s.getId());
    			//System.out.println("item"+item+"Id"+sequenceIDs);
    				
    			}
    			
    		}
    	}
    	/*for(Integer i : mapSequenceID.keySet()){
    		log.print(i+"|"+mapSequenceID.get(i).size()+"\n");
    		
    	}*/
    	return mapSequenceID;
    	
    }
    
    /*
     * 把正序列按长度分类
     */
    
    private void  classification(){
    	HashMap hh1 = new HashMap();
    	HashMap hh2 = new HashMap();
    	HashMap hh3 = new HashMap();
    	HashMap hh4 = new HashMap();
    	HashMap hh5 = new HashMap();
    	HashMap hh6 = new HashMap();
    	HashMap hh7 = new HashMap();
    	HashMap hh8 = new HashMap();
    	HashMap hh9 = new HashMap();
    	HashMap hh10 = new HashMap();
    	HashMap hh11 = new HashMap();
    	HashMap hh12 = new HashMap();
    	HashMap hh13 = new HashMap();
    	Iterator<SequentialPattern> it = tr.iterator();
    	ArrayList<Sequence> l1 =new ArrayList<Sequence>();
    	ArrayList<Sequence> l2 =new ArrayList<Sequence>();
    	ArrayList<Sequence> l3 =new ArrayList<Sequence>();
    	ArrayList<Sequence> l4 =new ArrayList<Sequence>();
    	ArrayList<Sequence> l5 =new ArrayList<Sequence>();
    	ArrayList<Sequence> l6 =new ArrayList<Sequence>();
    	ArrayList<Sequence> l7 =new ArrayList<Sequence>();
    	ArrayList<Sequence> l8 =new ArrayList<Sequence>();
    	ArrayList<Sequence> l9 =new ArrayList<Sequence>();
    	ArrayList<Sequence> l10 =new ArrayList<Sequence>();
    	ArrayList<Sequence> l11 =new ArrayList<Sequence>();
    	ArrayList<Sequence> l12 =new ArrayList<Sequence>();
    	ArrayList<Sequence> l13 =new ArrayList<Sequence>();
        	while(it.hasNext()){
        		SequentialPattern s = it.next();
        	//	System.out.println(s.getItemsets().toString()+","+s.getidlist().size());
        			if(s.getItemsets().size()==1){
            			
            			hh1.put(s.getItemsets().toString(), s.getidlist().size());
            			System.out.println("s"+s.getItemsets().toString()+","+s.getidlist().size());
            			OnePsp.add(s.getItemsets());
            			l1.add(s.getItemsets());
            		
        		}else if(s.getItemsets().size()==2){
        			BitSet aa = new BitSet();
        			for(Integer i : s.getidlist()){
        				aa.set(i,true);
        			}
        			//aa = (BitSet) s.getidlist();
        			//System.out.println(".............."+s.getItemsets());
        			System.out.println("s"+s.getItemsets().toString()+","+s.getidlist().size());
        			hh2.put(s.getItemsets().toString(), aa);
        			l2.add(s.getItemsets());
        		}else if(s.getItemsets().size()==3){
        			BitSet aa = new BitSet();
        			for(Integer i : s.getidlist()){
        				aa.set(i,true);
        			}
        			//aa = (BitSet) s.getidlist();
        			//System.out.println(".............."+s.getItemsets());
        			System.out.println("s"+s.getItemsets().toString()+","+s.getidlist().size());
        			hh3.put(s.getItemsets().toString(), aa);
        			l3.add(s.getItemsets());
        		}else if(s.getItemsets().size()==4){
        			BitSet aa = new BitSet();
        			for(Integer i : s.getidlist()){
        				aa.set(i,true);
        			}
        			//aa = (BitSet) s.getidlist();
        			//System.out.println(".............."+s.getItemsets());
        			System.out.println("s"+s.getItemsets().toString()+","+s.getidlist().size());
        			hh4.put(s.getItemsets().toString(), aa);
        			l4.add(s.getItemsets());
        		}else if(s.getItemsets().size()==5){
        			BitSet aa = new BitSet();
        			for(Integer i : s.getidlist()){
        				aa.set(i,true);
        			}
        			//aa = (BitSet) s.getidlist();
        			//System.out.println(".............."+s.getItemsets());
        			System.out.println("s"+s.getItemsets().toString()+","+s.getidlist().size());
        			hh5.put(s.getItemsets().toString(), aa);
        			l5.add(s.getItemsets());
        		}else if(s.getItemsets().size()==6){
        			BitSet aa = new BitSet();
        			for(Integer i : s.getidlist()){
        				aa.set(i,true);
        			}
        			//aa = (BitSet) s.getidlist();
        			//System.out.println(".............."+s.getItemsets());
        			hh6.put(s.getItemsets().toString(), aa);
        			l6.add(s.getItemsets());
        		}else if(s.getItemsets().size()==7){
        			BitSet aa = new BitSet();
        			for(Integer i : s.getidlist()){
        				aa.set(i,true);
        			}
        			//aa = (BitSet) s.getidlist();
        			//System.out.println(".............."+s.getItemsets());
        			hh7.put(s.getItemsets().toString(), aa);
        			l7.add(s.getItemsets());
        		}else if(s.getItemsets().size()==8){
        			BitSet aa = new BitSet();
        			for(Integer i : s.getidlist()){
        				aa.set(i,true);
        			}
        			//aa = (BitSet) s.getidlist();
        			//System.out.println(".............."+s.getItemsets());
        			hh8.put(s.getItemsets().toString(), aa);
        			l8.add(s.getItemsets());
        		}else if(s.getItemsets().size()==9){
        			BitSet aa = new BitSet();
        			for(Integer i : s.getidlist()){
        				aa.set(i,true);
        			}
        			//aa = (BitSet) s.getidlist();
        			//System.out.println(".............."+s.getItemsets());
        			hh9.put(s.getItemsets().toString(), aa);
        			l9.add(s.getItemsets());
        		}else if(s.getItemsets().size()==10){
        			BitSet aa = new BitSet();
        			for(Integer i : s.getidlist()){
        				aa.set(i,true);
        			}
        			//aa = (BitSet) s.getidlist();
        			//System.out.println(".............."+s.getItemsets());
        			hh10.put(s.getItemsets().toString(), aa);
        			l10.add(s.getItemsets());
        		}else if(s.getItemsets().size()==11){
        			BitSet aa = new BitSet();
        			for(Integer i : s.getidlist()){
        				aa.set(i,true);
        			}
        			//aa = (BitSet) s.getidlist();
        			//System.out.println(".............."+s.getItemsets());
        			hh11.put(s.getItemsets().toString(), aa);
        			l11.add(s.getItemsets());
        		}else if(s.getItemsets().size()==12){
        			BitSet aa = new BitSet();
        			for(Integer i : s.getidlist()){
        				aa.set(i,true);
        			}
        			//aa = (BitSet) s.getidlist();
        			//System.out.println(".............."+s.getItemsets());
        			hh12.put(s.getItemsets().toString(), aa);
        			l12.add(s.getItemsets());
        		}else{
        			BitSet aa = new BitSet();
        			for(Integer i : s.getidlist()){
        				aa.set(i,true);
        			}
        			//aa = (BitSet) s.getidlist();
        			//System.out.println(".............."+s.getItemsets());
        			hh13.put(s.getItemsets().toString(), aa);
        			l13.add(s.getItemsets());
        			//System.out.println("s"+s.getItemsets().toString()+","+s.getidlist().size());
        		}
                 
        		
        	//this.l.add(s.getItemsets());
        	
        	
    		
    	}
    	
    	if(hh1.size()>0){
    		//SetIDList.add(hh1);
    		max=1;
    		//addToResult(l1);
    	}
        if(hh2.size()>0){
    		//SetIDList.add(hh2);
        	max=2;
    		//addToResult(l2);
    	}
        if(hh3.size()>0){
    		//SetIDList.add(hh3);
        	max=3;
    		//addToResult(l3);
    	}
        if(hh4.size()>0){
    		//SetIDList.add(hh4);
        	max=4;
    		//addToResult(l4);
    	}
        if(hh5.size()>0){
    		//SetIDList.add(hh5);
        	max=5;
    		//addToResult(l5);
    	}
        if(hh6.size()>0){
    		//SetIDList.add(hh6);
        	max=6;
    		//addToResult(l6);
    	}if(hh7.size()>0){
    		//SetIDList.add(hh6);
        	max=7;
    		//addToResult(l6);
    	}if(hh8.size()>0){
    		//SetIDList.add(hh6);
        	max=8;
    		//addToResult(l6);
    	}if(hh9.size()>0){
    		//SetIDList.add(hh6);
        	max=9;
    		//addToResult(l6);
    	}if(hh10.size()>0){
    		//SetIDList.add(hh6);
        	max=10;
    		//addToResult(l6);
    	}if(hh11.size()>0){
    		//SetIDList.add(hh6);
        	max=11;
    		//addToResult(l6);
    	}if(hh12.size()>0){
    		//SetIDList.add(hh6);
        	max=12;
    		//addToResult(l6);
    	}if(hh13.size()>0){
    		//SetIDList.add(hh6);
        	max=13;
    		//addToResult(l6);
    	}
        	
        SetIDList.add(hh1);
        SetIDList.add(hh2);
        SetIDList.add(hh3);
        SetIDList.add(hh4);
        SetIDList.add(hh5);
        SetIDList.add(hh6);
        SetIDList.add(hh7);
        SetIDList.add(hh8);
        SetIDList.add(hh9);
        SetIDList.add(hh10);
        SetIDList.add(hh11);
        SetIDList.add(hh12);
        SetIDList.add(hh13);
        addToResult(l1);
        addToResult(l2);
        addToResult(l3);
        addToResult(l4);
        addToResult(l5);
        addToResult(l6);
        addToResult(l7);
        addToResult(l8);
        addToResult(l9);
        addToResult(l10);
        addToResult(l11);
        addToResult(l12);
        addToResult(l13);
        	
        	
    	//System.out.println(SetIDList);
    	
    }
    
    private void initializeNeg() {
		
    	//all positive sequence transform to negative sequence
    	ArrayList<Sequence> lneg = new ArrayList<Sequence>();
    	this.l1item = new ArrayList<Sequence>();
    	//l.clear();
    	l = new ArrayList<Sequence>();
    	//System.out.println("c____________"+OnePsp.size());
    
    	for(Sequence s : OnePsp){
    		
    		Sequence newe = new Sequence();
    	    l1item.add(s);
    	    
    	    
    	    Sequence news = new Sequence();
    	    news = s.clone();
    	    news.getElement(0).setItemsNeg();
    	  
    		
    	    lneg.add(news);
    		//l1item.add(news);
    		//System.out.println("l1item1"+l1item);
    		
    	}
    	// l1item中存储了 positive + negative 
    	
    	//以上完成了正序列模式转换为负序列模式
    	//System.out.println("l1item"+l1item);
    	//System.out.println(OnePsp);
    	if (lresult==null)  lresult = new ArrayList<Sequence>();
    	for(Sequence seqneg : lneg){
    		seqneg.getElement(0).setItemsNeg();
    		int isup = getFromHash(SetIDList.get(0),seqneg.toString());
    		seqneg.getElement(0).setItemsNeg();
    		seqneg.setSupport(source_db.size()-isup);
    		this.l.add(seqneg);
    		if(seqneg.getSupport()>this.support){
    			lresult.add(seqneg);
    			l1item.add(seqneg);
    			//this.l.add(seqneg);
    		}
    	}
    	System.out.println("c1:"+l1item);
    	addToResultNeg(lresult);
    	//for(Sequence seq : l){
    	//	System.out.println(seq+":"+seq.getSupport());
    	//}
    	
    	
    }
    /*
     * chan sheng length=2 hou xuan
     */
    private void genNegoneCandidate(){
    	
	//	c.clear();
    	
		this.c = new ArrayList<Sequence>();
		//System.out.println(this.c.size());
	    ArrayList<Sequence> lneg = new ArrayList<Sequence>();
	    //System.out.println("c____________"+pattern_db.get(0).size());
		for(Sequence s : pattern_db.get(0).getSeqs() ){
			
			for(int i = 0; i< l1item.size(); i++){
				
				if(l1item.get(i).getElement(0).getFirstItem()<0){
					this.joinAndInsertNeg(s, l1item.get(i));
				}
			}
		}
		//System.out.println("c____________"+this.l.size());
    	for(int j =0; j< this.l.size(); j++ ){
    		for(int i =0; i< l1item.size(); i++){
    			this.joinAndInsertNeg(l.get(j), l1item.get(i));
    		}
    	}
    	 //System.out.println("c____________"+this.c);
    	 SupportNeg(this.c);
    	// System.out.println("计算完长度为2的支持度"+lneg);
    	//addToResultNeg(lneg);
    	//System.out.println(lneg);
    }
    
    /*
     * chan sheng length>2 de houxuan
     */
    
    private void generNeg(SeqDB neg){
		//c.clear();
		//this.c = new ArrayList<Sequence>();
		//System.out.println(neg);
		//int a = 2*maxlength+1;
		//System.out.println(a);
    	ArrayList<Sequence> lneg = new ArrayList<Sequence>();
    	lneg = (ArrayList<Sequence>) this.c.clone();
    	c.clear();
    	for(Sequence s : lneg){
    		//System.out.println("------"+s);
    		for(int j = 0; j < l1item.size(); j++){
    			this.joinAndInsertNeg(s, l1item.get(j));
    		}
    	}
    	
    	for(Sequence s :neg.getSeqs()){
    		//System.out.println("++++++"+s);
    			for(int j =0; j < l1item.size(); j++){
    				this.joinAndInsertNeg(s , l1item.get(j));
    				
    			}
		}
    	//System.out.println("1"+c);
    	//lneg.clear();
    	 SupportNeg(this.c);
    	//System.out.println("2"+lneg);
    //	return lneg;
    	
    }
    
    
    private void joinAndInsertNeg(Sequence s1, Sequence s2){
    	Sequence st;
    	
    	Element ef = s1.getElement(s1.size()-1);
    	Element ee = s2.getElement(0);
    	
    	if(ef.getFirstItem()>0 || (ee.getFirstItem()>0 && ef.getFirstItem()<0)){
    		st = new Sequence();
    		st = s1.clone();
    		st.addElement(ee);
    		c.add(st);
    	}
    	return;
    }
    
    /*
     * Calculation support
     */
    
    private void SupportNeg(ArrayList<Sequence> neg){
    	//System.out.println("c"+neg.size());
    	//for(Sequence e: neg){
    	//	log.println(e.toString());
    	//}
    	//System.out.println("--------------66666666");
    	ArrayList<Sequence> lneg = new ArrayList<Sequence>();
    	ArrayList<Sequence> neglist = new ArrayList<Sequence>();
    	//System.out.println("neg"+neglist.size());
		for(int i=0; i<neg.size(); i++){
			Sequence seq = neg.get(i).clone();
			//log.print("seqsup"+seq.getSupport());
			Sequence seqneg = seq.getNegFromSeq();
			//System.out.println(seq);
			
			//-------------------1-neg----------------------------------------
			if(seqneg.size()==1){
				Sequence smp = seq.getPosFromSeq();
				Sequence sce = seq.getCounterExample();
				
				if(smp.size()==1){
					int isup = getFromHash(SetIDList.get(smp.size()-1), smp.toString());
					
					BitSet idmap=new BitSet();
					
					idmap = getIDMapFromHash(SetIDList.get(sce.size()-1), sce.toString());
					if(idmap==null||isup==0){
						continue;
					}
					isup = isup - idmap.cardinality();
					
					seq.setSupport(isup);
					lneg.add(seq);
					if (seq.getSupport()>(this.support)){
        				neglist.add(seq);
        				//log.print("--------1-"+seq.toString());
        			}
					
				}
				if (smp.size()>1){
					//log.println("seqneg"+seqneg);
					//log.println("smp"+smp);
					//log.println("sce"+sce);
					BitSet idmap1=new BitSet();
					BitSet idmap2=new BitSet();
					//System.out.println("sce"+sce);
					//System.out.println(SetIDList.get(2));
					idmap1 = getIDMapFromHash(SetIDList.get(smp.size()-1), smp.toString()); 
					idmap2 = getIDMapFromHash(SetIDList.get(sce.size()-1), sce.toString());
					//log.println("idmap1"+idmap1);
					//log.println("idmap2"+idmap2);
					if(idmap1==null || idmap2==null){
						
						continue;
						
					}
					//log.println("chenggong");
					BitSet idmapdiff = bitdiff(idmap1, idmap2);
					//log.println("idmapdiff"+idmapdiff);
					seq.setSupport(idmapdiff.cardinality());
					lneg.add(seq);
					//System.out.print("seqsup"+seq.getSupport());
					if (seq.getSupport()>(this.support)){
        				neglist.add(seq);
        				//log.print("------------1-"+seq.toString());
        			}
					
				}
				
				
			}
			
			//---------------------------- 2-neg-----------------------------------------
			if(seqneg.size()==2){
				//log.print("seq"+seq);
				//log.print("seqneg"+seqneg);
				Sequence smp = seq.getPosFromSeq();
				Sequence sce1 = seq.getCounterExampleX(0);
				//log.print("seqeeeee"+seq);
				Sequence sce2 = seq.getCounterExampleX(1);
				//log.print("sce1"+sce1);
				//log.print("sce2"+sce2);
				if(smp.size()==1){
					int isup = getFromHash(SetIDList.get(smp.size()-1), smp.toString());
					BitSet idmap1 = getIDMapFromHash(SetIDList.get(sce1.size()-1), sce1.toString()); 
					BitSet idmap2 = getIDMapFromHash(SetIDList.get(sce2.size()-1), sce2.toString());
					if(idmap1==null || idmap2==null){
						continue;
					}
					BitSet idmapand = bitand(idmap1, idmap2);
					isup= isup-idmapand.cardinality();
					seq.setSupport(isup);
					lneg.add(seq);
					if (seq.getSupport()>(this.support)){
        				neglist.add(seq);
        				//log.print("------------2-"+seq.toString());
        			}
				}
				
				if (smp.size()>1){
					BitSet idmap = getIDMapFromHash(SetIDList.get(smp.size()-1), smp.toString());
					BitSet idmap1 = getIDMapFromHash(SetIDList.get(sce1.size()-1), sce1.toString()); 
					BitSet idmap2 = getIDMapFromHash(SetIDList.get(sce2.size()-1), sce2.toString());
					
					if(idmap1==null || idmap2==null){
						continue;
					}
					BitSet idmapand = bitand(idmap1, idmap2);
					BitSet idmapdiff = bitdiff(idmap, idmapand);
					seq.setSupport(idmapdiff.cardinality());
					lneg.add(seq);
					if (seq.getSupport()>(this.support)){
        				neglist.add(seq);
        				//log.print("----------2-"+seq.toString());
        			}
				}
			}
			
			//----------------------- 3-neg-----------------------
			
			if(seqneg.size()==3){
				//log.print(seq.toString());
				Sequence smp = seq.getPosFromSeq();
				Sequence sce1 = seq.getCounterExampleX(0);
				Sequence sce2 = seq.getCounterExampleX(1);
				Sequence sce3 = seq.getCounterExampleX(2);
				if (smp.size()>1){
					BitSet idmap = getIDMapFromHash(SetIDList.get(smp.size()-1), smp.toString());
					BitSet idmap1 = getIDMapFromHash(SetIDList.get(sce1.size()-1), sce1.toString()); 
					BitSet idmap2 = getIDMapFromHash(SetIDList.get(sce2.size()-1), sce2.toString());
					BitSet idmap3 = getIDMapFromHash(SetIDList.get(sce3.size()-1), sce3.toString());
					if(idmap1==null || idmap2==null || idmap3==null){
						continue;
					}
					BitSet idmapand = bitand(idmap1, idmap2);
					idmapand = bitand(idmapand, idmap3);
					BitSet idmapdiff = bitdiff(idmap, idmapand);
					seq.setSupport(idmapdiff.cardinality());
					lneg.add(seq);
					if (seq.getSupport()>(this.support)){
        				neglist.add(seq);
        				//log.print("---------3-"+seq.toString());
        			}
				}
				
			}
			
			//---------------------------4-neg----------------------
			if(seqneg.size()==4){
				Sequence smp = seq.getPosFromSeq();
				Sequence sce1 = seq.getCounterExampleX(0);
				Sequence sce2 = seq.getCounterExampleX(1);
				Sequence sce3 = seq.getCounterExampleX(2);      
				Sequence sce4 = seq.getCounterExampleX(3); 
				if (smp.size()>1){ 
					BitSet idmap = getIDMapFromHash(SetIDList.get(smp.size()-1), smp.toString());
					BitSet idmap1 = getIDMapFromHash(SetIDList.get(sce1.size()-1), sce1.toString()); 
					BitSet idmap2 = getIDMapFromHash(SetIDList.get(sce2.size()-1), sce2.toString());
					BitSet idmap3 = getIDMapFromHash(SetIDList.get(sce3.size()-1), sce3.toString());
					BitSet idmap4 = getIDMapFromHash(SetIDList.get(sce4.size()-1), sce4.toString());
					if(idmap1==null || idmap2==null || idmap3==null || idmap4==null){
						continue;
					}
					BitSet idmapand = bitand(idmap1, idmap2);
					
					idmapand = bitand(idmapand, idmap3);
					idmapand = bitand(idmapand, idmap4);
					BitSet idmapdiff = bitdiff(idmap, idmapand);
					seq.setSupport(idmapdiff.cardinality());
					lneg.add(seq);
					if (seq.getSupport()>(this.support)){
        				neglist.add(seq);
        				//log.print("---------4-"+seq.toString());
        			}
				}
			} 
			
			//------------------------- 5-neg --------------------
			if(seqneg.size()==5){
				Sequence smp = seq.getPosFromSeq();
				Sequence sce1 = seq.getCounterExampleX(0);
				Sequence sce2 = seq.getCounterExampleX(1);
				Sequence sce3 = seq.getCounterExampleX(2);      
				Sequence sce4 = seq.getCounterExampleX(3);  
				Sequence sce5 = seq.getCounterExampleX(4);
				if (smp.size()>1){ 
					BitSet idmap = getIDMapFromHash(SetIDList.get(smp.size()-1), smp.toString());
					BitSet idmap1 = getIDMapFromHash(SetIDList.get(sce1.size()-1), sce1.toString()); 
					BitSet idmap2 = getIDMapFromHash(SetIDList.get(sce2.size()-1), sce2.toString());
					BitSet idmap3 = getIDMapFromHash(SetIDList.get(sce3.size()-1), sce3.toString());
					BitSet idmap4 = getIDMapFromHash(SetIDList.get(sce4.size()-1), sce4.toString());
					BitSet idmap5 = getIDMapFromHash(SetIDList.get(sce5.size()-1), sce5.toString());
					if(idmap1==null || idmap2==null || idmap3==null || idmap4==null || idmap5==null){
						continue;
					}
					BitSet idmapand = bitand(idmap1, idmap2);
					idmapand = bitand(idmapand, idmap3);
					idmapand = bitand(idmapand, idmap4);
					idmapand = bitand(idmapand, idmap5);
					BitSet idmapdiff = bitdiff(idmap, idmapand);
					seq.setSupport(idmapdiff.cardinality());
					lneg.add(seq);
					if (seq.getSupport()>(this.support)){
        				neglist.add(seq);
        				//log.print("---------5-"+seq.toString());
        			}
				}
			}
			//------------------------- 6-neg --------------------
			if(seqneg.size()==6){
				//System.out.println("--------------66666666");
				Sequence smp = seq.getPosFromSeq();
				Sequence sce1 = seq.getCounterExampleX(0);
				Sequence sce2 = seq.getCounterExampleX(1);
				Sequence sce3 = seq.getCounterExampleX(2);      
				Sequence sce4 = seq.getCounterExampleX(3);  
				Sequence sce5 = seq.getCounterExampleX(4);
				Sequence sce6 = seq.getCounterExampleX(5);
				if (smp.size()>1){ 
					BitSet idmap = getIDMapFromHash(SetIDList.get(smp.size()-1), smp.toString());
					BitSet idmap1 = getIDMapFromHash(SetIDList.get(sce1.size()-1), sce1.toString()); 
					BitSet idmap2 = getIDMapFromHash(SetIDList.get(sce2.size()-1), sce2.toString());
					BitSet idmap3 = getIDMapFromHash(SetIDList.get(sce3.size()-1), sce3.toString());
					BitSet idmap4 = getIDMapFromHash(SetIDList.get(sce4.size()-1), sce4.toString());
					BitSet idmap5 = getIDMapFromHash(SetIDList.get(sce5.size()-1), sce5.toString());
					BitSet idmap6 = getIDMapFromHash(SetIDList.get(sce6.size()-1), sce6.toString());
					if(idmap1==null || idmap2==null || idmap3==null || idmap4==null || idmap5==null|| idmap6==null){
						continue;
					}
					BitSet idmapand = bitand(idmap1, idmap2);
					idmapand = bitand(idmapand, idmap3);
					idmapand = bitand(idmapand, idmap4);
					idmapand = bitand(idmapand, idmap5);
					idmapand = bitand(idmapand, idmap6);
					BitSet idmapdiff = bitdiff(idmap, idmapand);
					seq.setSupport(idmapdiff.cardinality());
					lneg.add(seq);
					if (seq.getSupport()>(this.support)){
        				neglist.add(seq);
        				//log.print("---------5-"+seq.toString());
        			}
				}
			}
			//------------------------- 7-neg --------------------
			if(seqneg.size()==7){
				//System.out.println("--------------66666666");
				Sequence smp = seq.getPosFromSeq();
				Sequence sce1 = seq.getCounterExampleX(0);
				Sequence sce2 = seq.getCounterExampleX(1);
				Sequence sce3 = seq.getCounterExampleX(2);      
				Sequence sce4 = seq.getCounterExampleX(3);  
				Sequence sce5 = seq.getCounterExampleX(4);
				Sequence sce6 = seq.getCounterExampleX(5);
				Sequence sce7 = seq.getCounterExampleX(6);
				if (smp.size()>1){ 
					BitSet idmap = getIDMapFromHash(SetIDList.get(smp.size()-1), smp.toString());
					BitSet idmap1 = getIDMapFromHash(SetIDList.get(sce1.size()-1), sce1.toString()); 
					BitSet idmap2 = getIDMapFromHash(SetIDList.get(sce2.size()-1), sce2.toString());
					BitSet idmap3 = getIDMapFromHash(SetIDList.get(sce3.size()-1), sce3.toString());
					BitSet idmap4 = getIDMapFromHash(SetIDList.get(sce4.size()-1), sce4.toString());
					BitSet idmap5 = getIDMapFromHash(SetIDList.get(sce5.size()-1), sce5.toString());
					BitSet idmap6 = getIDMapFromHash(SetIDList.get(sce6.size()-1), sce6.toString());
					BitSet idmap7 = getIDMapFromHash(SetIDList.get(sce7.size()-1), sce7.toString());
					if(idmap1==null || idmap2==null || idmap3==null || idmap4==null || idmap5==null|| idmap6==null|| idmap7==null){
						continue;
					}
					BitSet idmapand = bitand(idmap1, idmap2);
					idmapand = bitand(idmapand, idmap3);
					idmapand = bitand(idmapand, idmap4);
					idmapand = bitand(idmapand, idmap5);
					idmapand = bitand(idmapand, idmap6);
					idmapand = bitand(idmapand, idmap7);
					BitSet idmapdiff = bitdiff(idmap, idmapand);
					seq.setSupport(idmapdiff.cardinality());
					lneg.add(seq);
					if (seq.getSupport()>(this.support)){
        				neglist.add(seq);
        				//log.print("---------5-"+seq.toString());
        			}
				}
			}
			//------------------------- 8-neg --------------------
			if(seqneg.size()==8){
				//System.out.println("--------------66666666");
				Sequence smp = seq.getPosFromSeq();
				Sequence sce1 = seq.getCounterExampleX(0);
				Sequence sce2 = seq.getCounterExampleX(1);
				Sequence sce3 = seq.getCounterExampleX(2);      
				Sequence sce4 = seq.getCounterExampleX(3);  
				Sequence sce5 = seq.getCounterExampleX(4);
				Sequence sce6 = seq.getCounterExampleX(5);
				Sequence sce7 = seq.getCounterExampleX(6);
				Sequence sce8 = seq.getCounterExampleX(7);
				if (smp.size()>1){ 
					BitSet idmap = getIDMapFromHash(SetIDList.get(smp.size()-1), smp.toString());
					BitSet idmap1 = getIDMapFromHash(SetIDList.get(sce1.size()-1), sce1.toString()); 
					BitSet idmap2 = getIDMapFromHash(SetIDList.get(sce2.size()-1), sce2.toString());
					BitSet idmap3 = getIDMapFromHash(SetIDList.get(sce3.size()-1), sce3.toString());
					BitSet idmap4 = getIDMapFromHash(SetIDList.get(sce4.size()-1), sce4.toString());
					BitSet idmap5 = getIDMapFromHash(SetIDList.get(sce5.size()-1), sce5.toString());
					BitSet idmap6 = getIDMapFromHash(SetIDList.get(sce6.size()-1), sce6.toString());
					BitSet idmap7 = getIDMapFromHash(SetIDList.get(sce7.size()-1), sce7.toString());
					BitSet idmap8 = getIDMapFromHash(SetIDList.get(sce8.size()-1), sce8.toString());
					if(idmap1==null || idmap2==null || idmap3==null || idmap4==null || idmap5==null|| idmap6==null|| idmap7==null|| idmap8==null){
						continue;
					}
					BitSet idmapand = bitand(idmap1, idmap2);
					idmapand = bitand(idmapand, idmap3);
					idmapand = bitand(idmapand, idmap4);
					idmapand = bitand(idmapand, idmap5);
					idmapand = bitand(idmapand, idmap6);
					idmapand = bitand(idmapand, idmap7);
					idmapand = bitand(idmapand, idmap8);
					BitSet idmapdiff = bitdiff(idmap, idmapand);
					seq.setSupport(idmapdiff.cardinality());
					lneg.add(seq);
					if (seq.getSupport()>(this.support)){
        				neglist.add(seq);
        				//log.print("---------5-"+seq.toString());
        			}
				}
			}
		}
		//log.print("----------------1--------------------");
    	//for(Sequence ss:neglist){
    		
    //		log.println(ss.toString());
    	//}
    //	log.print("-----------------2-------------------");
    //	System.out.println("neglist"+neglist.size());
		addToResultNeg(neglist);
		c.clear();
		this.c = (ArrayList<Sequence>) lneg.clone();
		//for(Sequence sssss: lneg){
		//	System.out.println(sssss+","+sssss.getSupport());
		//}
		System.out.println("c++"+this.c.size());
    	//return neglist;//此处要改
    	
    }
    
  
  
    private BitSet bitand(BitSet a,BitSet b){
    	BitSet n1=new BitSet();
    	BitSet n2=new BitSet();
    	n1=(BitSet) a.clone();
    	n2=(BitSet) b.clone();
    	n1.or(n2);
    	return n1;
    }
    
    
    
    private BitSet bitdiff(BitSet a,BitSet b) {
    	BitSet n1=new BitSet();
    	BitSet n2=new BitSet();
    	n1=(BitSet) a.clone();
    	n2=(BitSet) b.clone();

    	//n2.and(n1);
    	n1.xor(n2);
    	
		return n1;   	
	}
    
    private ArrayList<Integer> getDiff(ArrayList<Integer> listSupperSet, ArrayList<Integer> listSubSet){
    	
    	ArrayList<Integer> l1 = new ArrayList<Integer>();
    	ArrayList<Integer> l2 = new ArrayList<Integer>();
    	for (int i=0; i<listSupperSet.size(); i++){
    		l1.add(listSupperSet.get(i));
    	}
    	for (int i=0; i<listSubSet.size(); i++){
    		l2.add(listSubSet.get(i));
    	}
    	
    	int i=0, j=0;
    	while ( i < l1.size() && j < l2.size() ){
    			int i1 = l1.get(i);
    			int i2 = l2.get(j);
    			
    			if ( i1 == i2) {
    				l1.remove(i);
    				//l2.remove(j);
    				j++;
    			} else if ( i1 > i2) {
    				j++;
    			} else {
    				i++;
    			}
    	}    	
    	
    	return l1;
    	
    }
    
    
private ArrayList<Integer> getAnd(ArrayList<Integer> listSupperSet, ArrayList<Integer> listSubSet){
    	
	/*
    	ArrayList<Integer> l1 = new ArrayList<Integer>();
    	ArrayList<Integer> l2 = new ArrayList<Integer>();
    	for (int i=0; i<listSupperSet.size(); i++){
    		l1.add(listSupperSet.get(i));
    	}
    	for (int i=0; i<listSubSet.size(); i++){
    		l2.add(listSubSet.get(i));
    	}
    	
    	int i=0, j=0;
    	while ( i < l1.size() && j < l2.size() ){
    			int i1 = l1.get(i);
    			int i2 = l2.get(j);
    			
    			if ( i1 > i2) {
    				l1.add(i,i2);
    				//i++;
    				j++;
    			} else if ( i1 < i2) {
    				i++;
    			} else {
    				i++;
    				j++;
    			}
    	}    	
    	
    	return l1;
    	*/  
			ArrayList<Integer> l1 = new ArrayList<Integer>();
	    	ArrayList<Integer> l2 = new ArrayList<Integer>();
	    	ArrayList<Integer> l3 = new ArrayList<Integer>();
	    	for (int i=0; i<listSupperSet.size(); i++){
	    		l1.add(listSupperSet.get(i));
	    	}
	    	for (int i=0; i<listSubSet.size(); i++){
	    		l2.add(listSubSet.get(i));
	    	}
	    	
	    	int i=0, j=0;
	    	while ( i < l1.size() && j < l2.size() ){
	    			
	    			
	    			int i1 = l1.get(i);
	    			int i2 = l2.get(j);
	    			
	    			if ( i1 > i2) {
	    				l3.add(i2);	    				
	    				j++;
	    			} else if ( i1 < i2) {
	    				l3.add(i1);
	    				i++;
	    			} else {
	    				l3.add(i1);
	    				i++;
	    				j++;
	    			}
	    	}  
	    	
	    	while (i<l1.size()) {
	    		l3.add(l1.get(i));
	    		i++;
	    	}
	    	while (j<l2.size()) {
	    		l3.add(l2.get(j));
	    		j++;
	    	}
	    	
	    	return l3;
		
	
    	
    }
    
    private int getFromHash(HashMap ht, String strKey){
    	int isup = 0;
    	//System.out.println("-------------------"+ht);
    	//System.out.println("-------------------"+ht.get(strKey));
    	isup = (Integer)ht.get(strKey);
    	//System.out.println("-------");
    	return isup;
    }
    
    private ArrayList<Integer> getIDListFromHash(Hashtable ht, String strKey){
    	//System.out.println("..........."+ht);
    	//System.out.println("..........."+ht.get(strKey));
    	ArrayList<Integer> strList = new ArrayList<Integer>();
    	
    	strList = (ArrayList<Integer>) ht.get(strKey);
    	//System.out.println("..........."+strList);
    	return strList;
    }
    
    private BitSet getIDMapFromHash(HashMap ht, String strKey){
    	
    	BitSet strmap = new BitSet();
    	
    	strmap = (BitSet) ht.get(strKey);
    	
    	return strmap;
    }  
    
    
   
    /*
     * add the frequent sequence pattern into result set
     */
    private void addToResult(ArrayList<Sequence> l) { 
       //System.out.println("oooooooo"+l);
    	//for(Sequence s:l){
    	//	System.out.println("sss"+s);
    	//}
    	pattern_db.add(new SeqDB(l));
    }
    
    private void addToResultNeg(ArrayList<Sequence> l) { 
       
    	pattern_db_neg.add(new SeqDB(l));
    }

    /**
     * output the sequential pattern
     */
   public void outputInput() {
          log.println("support is: " + this.support);
          log.println("");
   }
   
   /**
    * set algorithm type, whether it can do negative sequence mining
    */
   public void setNegative(boolean isNeg){
	   this.negative = isNeg;
   }
   
   public long getSumRuntime(){
	   return sumruntime;
   }
   
   public long getPosRuntime(){
	   return posruntime;
   }

   public long getNSCsum(){
	   return NSCsum;
   }
   public String getSequenceCountString(){
	   return SequenceCountString;
   }
   public double getmemory() {

	   double mey=(double)memory;
	   mey=(mey/(1024*1024));
	   return mey;
}
   public double getsidavg() {

	   double sidavg=(double)avg;
	   sidavg=(sidavg/sidcount);
	   return sidavg;
}
   
   public int getPatternsCount(){
	   
	   int iCount = 0;
	   for (int j=0; j< pattern_db_neg.size(); j++){
       		SeqDB sdb = pattern_db_neg.get(j);
       		for (int k=0;k<sdb.getSeqs().size();k++){
       			iCount ++;
       		}       	
       }
	   return iCount;
   }
}

