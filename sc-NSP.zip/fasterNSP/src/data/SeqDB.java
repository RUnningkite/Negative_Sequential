package data;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;


import sequence.*;

/**

 * <title>Data Source Class for all algorithm</title>
 * read data from file or database, store in sequence list.
 *
 */

public class SeqDB {

    private ArrayList<Sequence> seqs;  //all data sequence list
    private String datafile;		   // data file name
    public int lenmin;
    public int lenmax;
    public int lenaverage;

    public SeqDB() {

        this.seqs = new ArrayList<Sequence>();
    }
    
    public SeqDB(ArrayList<Sequence> ss) {
        this.seqs = new ArrayList<Sequence>();
        for (Sequence s:ss){
    		seqs.add(s);
    	}
    }
   
    public void loaddata(int loadtype,String filename){
    	//System.out.println("type"+loadtype);
    	if (loadtype == 2)  load_2(filename);
    	if (loadtype == 3)  load_3(filename);
    	if (loadtype == 4)  load_4(filename);
    }    
	
    public void LoadSequences(ArrayList<Sequence> ss){
    	seqs = ss;
    	//System.out.println(seqs.toString());    	
    }
    
    /**
     * load data from file
     * data type: one record is one sequence, ie: 1,12 3 2 1 4 1 3
     * @return size of data set
     */
    private void load_2(String filename){
    	
    	Sequence s;
    	int min=99999, max=0, average=0;
    	
    	File myFile = new File(filename); 
    	if(myFile.exists()){ 
    		try{
    			BufferedReader br=new BufferedReader(new FileReader(filename));
    	        String temp = br.readLine();
    	        while (temp!=null){
    	            s = new Sequence();
    	            String[] temp1 = temp.split(" ");//split切分字符
    	            for (int i=0;i<temp1.length;i++){
    	            	//s.addElement(new Element(new int[] {Integer.parseInt(temp1[i].toString())}));
    	            	int[] a = {Integer.parseInt(temp1[i].toString())};
    	            	s.addElement(new Element(a));
    	            }
    	            seqs.add(s);
    	            if (s.size()>max) max = s.size();
    	            if (s.size()<min) min = s.size();
    	            average = average + s.size();
    	            temp = br.readLine();
    	        }
    	        lenaverage = average/seqs.size();
    	        lenmin = min;
    	        lenmax = max;
            }
    		catch(Exception e){
    			//System.err.println(e);
    			JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
    		}	
    	}
    	else { 
    		System.out.println("file:" + filename + " doesn't exist!" );
    	}
    }
    
    /**
     * load data from file
     * data type: one record is one element of sequence, ie: 1,1,14; 1,2,15; 1,3,42; 2,1,111....
     * @return size of data set
     */    
    private void load_3(String filename){
    	
    	Sequence s;
    	int min=99999, max=0, average=0;
    	
    	File myFile = new File(filename); 
    	if(myFile.exists()){ 
    		try{
    			BufferedReader br=new BufferedReader(new FileReader(filename));
    			
    	        String temp = br.readLine();
    	        String strdata="";
    	        int tid=-1, oldtid=-1, oid = -1, oldoid=-1;
    	        s = new Sequence();
    	        Element e = new Element();  
    	       
    	        while (temp!=null){
    	        	
    	        	//System.out.println(temp.toString());
    	        	String[] temp0 = temp.split(" ");
    	        	String[] temp1 = new String[3];
    	        	
    	        	int i=0;
    	        	for (int m=0; m<temp0.length; m++){
    	        		if (!temp0[m].toString().equals("")) {
    	        			temp1[i++] = temp0[m];
    	        		}
    	        		
    	        	}
    	        	
    	            tid = Integer.parseInt(temp1[0].toString());
    	            oid = Integer.parseInt(temp1[1].toString());
    	            strdata = temp1[2].toString();
    	        //  System.out.println(strdata);
    	            if (tid!=oldtid){
    	            	//System.out.println("e"+e);
    	            	
    	            	s.addElement(e);
    	            	
    	            	s.setId(oldtid);
    	            	
    	            	//System.out.println("s"+s);
    	            	//System.out.println("id"+s.getId());
    	            	//for(int k=5;k>0;k--){
    	            	seqs.add(s);
    	            	//System.out.println("---------2---");
    	            	//}
    	            	//System.out.println(s.toString());    	            	
    	            	if (s.size()>max) max = s.size();
    	            	
        	            if (s.size()<min && s.size()>0) min = s.size();
        	           // System.out.println("---------3---");
        	            average = average + s.size();
    	            	s = new Sequence();
    	            	e = new Element();    	     
	            		e.removeItem(0);
	            		
    	            	oldoid = -1;
    	            	
    	            } else {   
    	            	if (oid!=oldoid){
    	            		s.addElement(e);
    	            		e = new Element();    	     
    	            		e.removeItem(0);
    	            	}    	            	
    	            }
    	            e.addItem(Integer.parseInt(strdata));
    	           // System.out.println("E"+e);
    	            oldtid = tid;	            	
            		oldoid = oid;    	               	            
    	            temp = br.readLine();    	            
    	        }    	
    	        s.addElement(e);
    	       // s.setId(tid);
    	       // System.out.println("id"+s.getId());
    	       // for(int k=5;k>0;k--){
    	        seqs.add(s);
    	       // }
    	       // System.out.println(s.toString());
    	        
    	        seqs.remove(0);
    	        for(Sequence a: seqs){
    	        	//System.out.println("s"+ a);
    	        	//System.out.println("id"+a.getId());
    	        }
    	        lenaverage = average/seqs.size();
    	        lenmin = min;
    	        lenmax = max;
            
    		}
    		catch(Exception e){
    			
    			//System.err.println(e);
    			//JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
    		}	
    	}
    	else { 
    		System.out.println("file:" + filename + " doesn't exist!" ); 
    	}
    }
    
    
    /**
     * load data from file
     * data type: one record is one element of sequence, ie: 1,1,14,C2; 1,2,15,C2; 1,3,42,C2; 2,1,111,C1; ....
     * @return size of data set
     */    
    private void load_4(String filename){
    	//System.out.println("4");
    	Sequence s;
    	int min=99999, max=0, average=0;
    	
    	File myFile = new File(filename); 
    	if(myFile.exists()){ 
    		try{
    			BufferedReader br=new BufferedReader(new FileReader(filename));
    	        String temp = br.readLine();
    	        String strdata="";
    	        String strlabel = "", oldstrlabel="";
    	        int id = 0;
    	        int tid=-1, oldtid=-1;
    	        String oid = "-1", oldoid="-1";
    	        s = new Sequence();
    	        Element e = new Element();        		
    	        while (temp!=null){
    	        	//System.out.println(temp.toString());
    	        	String[] temp0 = temp.split(" ");
    	        	String[] temp1 = new String[4];
    	        	int i=0;
    	        	for (int m=0; m<temp0.length; m++){
    	        		if (!temp0[m].toString().equals("")) {
    	        			temp1[i++] = temp0[m];
    	        		}
    	        	}
    	            tid = Integer.parseInt(temp1[0].toString());
    	            oid = temp1[1].toString();
    	            strdata = temp1[2].toString();
    	            strlabel = temp1[3].toString();
    	            if (tid!=oldtid){
    	            	s.addElement(e);
    	            	s.setId(id);
    	            	s.setLabel(oldstrlabel);
    	            	seqs.add(s);
    	            	id++;
    	            	//System.out.println(s.toString()); 
    	            	//System.out.println(s.getId()); 
    	            	if (s.size()>max) max = s.size();
        	            if (s.size()<min && s.size()>0) min = s.size();
        	            average = average + s.size();
    	            	s = new Sequence();
    	            	e = new Element();    	     
	            		e.removeItem(0);
    	            	oldoid = "-1";
    	            	oldstrlabel = strlabel;
    	            } else {   
    	            	if (!oid.equals(oldoid)){
    	            		s.addElement(e);
    	            		e = new Element();    	     
    	            		e.removeItem(0);
    	            	}    	            	
    	            }
    	            e.addItem(Integer.parseInt(strdata));
    	            oldtid = tid;	            	
            		oldoid = oid;    	               	            
    	            temp = br.readLine();    	            
    	        }    	
    	        s.addElement(e);
        		s.setLabel(strlabel);
        		s.setId(id);
    	        seqs.add(s);
    	        //System.out.println(s.toString());
    	        //System.out.println(s.getId());
    	        seqs.remove(0);
    	        
    	        lenaverage = average/seqs.size();
    	        lenmin = min;
    	        lenmax = max;
            }
    		catch(Exception e){
    			//System.err.println(e);
    		//JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
    		}	
    	}
    	else { 
    		System.out.println("file:" + filename + " doesn't exist!" ); 
    	}
    }
    /**
     * load data from file
     * data type: one record is one element of sequence, ie: 1,1,14; 1,2,15; 1,3,42; 2,1,111....
     * @return size of data set
     */ 
    /*
    private void load_3(String filename){
    	
    	Sequence s;
    	int min=99999, max=0, average=0;
    	
    	File myFile = new File(filename); 
    	if(myFile.exists()){ 
    		try{
    			BufferedReader br=new BufferedReader(new FileReader(filename));
    	        String temp = br.readLine();
    	        String strdata="";
    	        int tid=-1, oldtid=-1;//, orderid = -1;
    	        s = new Sequence();
    	        while (temp!=null){
    	        	//System.out.println(temp.toString());
    	        	String[] temp0 = temp.split(" ");
    	        	String[] temp1 = new String[3];
    	        	int n=0;
    	        	for (int m=0; m<temp0.length; m++){
    	        		String a = temp0[m].toString(); 
    	        		//System.out.println("a=|" + a + "|");
    	        		if (!a.equals("")) {
    	        			temp1[n++] = temp0[m];
    	        		}
    	        	}
    	            tid = Integer.parseInt(temp1[0].toString());
    	            strdata = temp1[2].toString();
    	            if (tid!=oldtid){
    	            	seqs.add(s);
    	            	//System.out.println(s.toString());
    	            	if (s.size()>max) max = s.size();
        	            if (s.size()<min && s.size()>0) min = s.size();
        	            average = average + s.size();
    	            	s = new Sequence();
    	            	oldtid = tid;
    	            }    
    	            int[] a = {Integer.parseInt(strdata)};
    	            s.addElement(new Element(a));
    	            //s.addElement(new Element(new int[] {Integer.parseInt(strdata)}));    	            
    	            temp = br.readLine();    	            
    	        }    	   
    	        seqs.add(s);
    	        //System.out.println(s.toString());
    	        seqs.remove(0);
    	        
    	        lenaverage = average/seqs.size();
    	        lenmin = min;
    	        lenmax = max;
            }
    		catch(Exception e){
    			System.err.println(e);
    			JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
    		}	
    	}
    	else { 
    		System.out.println("file:" + filename + " doesn't exist!" ); 
    	}
    }*/
    	
    /**
     * get data set size
     * @return size of data set
     */
    public int size(){
        return this.seqs.size();
    }

    /**
     * get the data set
     * @return  data set: ArrayList
     */
    public ArrayList<Sequence> getSeqs(){
        return this.seqs;
    }

}

