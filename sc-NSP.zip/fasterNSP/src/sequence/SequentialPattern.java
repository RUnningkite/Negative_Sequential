package sequence;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;






public class SequentialPattern implements Comparable<SequentialPattern>{
	// the list of itemsets
	private  Sequence itemsets;
   //	private int id; 
	
	// IDs of sequences containing this pattern
	private Set<Integer> sequencesIds;
	
	private int itemCount = -1;
	
	/**
	 * Set the set of IDs of sequence containing this prefix
	 * @param a set of integer containing sequence IDs
	 */
	public void setSequenceIDs(Set<Integer> sequencesIds) {
		this.sequencesIds = sequencesIds;
	}
	
	/**
	 * Defaults constructor
	 */
	public SequentialPattern(){
		itemsets = new Sequence();
	}
	
	public SequentialPattern(Element itemset, Set<Integer> sequencesIds){
		itemsets = new Sequence();
		this.itemsets.addElement(itemset);
		this.sequencesIds = sequencesIds;
	}
	
	public SequentialPattern(Sequence itemsets, Set<Integer> sequencesIds){
		this.itemsets = itemsets;
		this.sequencesIds = sequencesIds;
	}
	
	/**
	 * Get the relative support of this pattern (a percentage)
	 * @param sequencecount the number of sequences in the original database
	 * @return the support as a string
	 */
	public String getRelativeSupportFormated(int sequencecount) {
		double relSupport = ((double)sequencesIds.size()) / ((double) sequencecount);
		// pretty formating :
		DecimalFormat format = new DecimalFormat();
		format.setMinimumFractionDigits(0); 
		format.setMaximumFractionDigits(5); 
		return format.format(relSupport);
	}
	
	/**
	 * Get the absolute support of this pattern.
	 * @return the support (an integer >= 1)
	 */
	public int getAbsoluteSupport(){
		return sequencesIds.size();
	}
	
	public Set<Integer> getidlist(){
		return sequencesIds;
	}
	
	/**
	 * Add an itemset to this sequential pattern
	 * @param itemset the itemset to be added
	 */
	public void addItemset(Element itemset) {
//		itemCount += itemset.size();
		itemsets.addElement(itemset);
	}
	
	/**
	 * Make a copy of this sequential pattern
	 * @return the copy.
	 */
	public SequentialPattern cloneSequence(){
		// create a new empty sequential pattenr
		SequentialPattern sequence = new SequentialPattern();
		// for each itemset
		for(Element itemset : itemsets.getElements()){
			// make a copy and add it
			sequence.addItemset(itemset.clone());
		}
		return sequence; // return the copy
	}
	
	/**
	 * Print this sequential pattern to System.out
	 */
	public void print() {
		System.out.print(toString());
	}
	
	/**
	 * Get the itemsets in this sequential pattern
	 * @return a list of itemsets.
	 */
	public Sequence getItemsets() {
		return itemsets;
	}
	
	   /**
     * overload toString()
     */
    public String toString() {
        StringBuffer s = new StringBuffer();
        s.append("<");
        for (int i = 0; i < this.itemsets.size(); i++) {
        	Element e = itemsets.getElement(i);
        	if (e.size()!=1) s.append("(");
            s.append(this.itemsets.getElement(i));
            if (e.size()!=1) s.append(")");
            if (i != this.itemsets.size() - 1) {
                s.append(" ");
            }
        }
        s.append(">");
        return s.toString();
    }
	
	/**
	 * Get an itemset at a given position.
	 * @param index the position
	 * @return the itemset
	 */
	public Element get(int index) {
		return itemsets.getElement(index);
	}
	
	

	@Override
	public int compareTo(SequentialPattern o) {
		if(o == this){
			return 0;
		}
		int compare = this.getAbsoluteSupport() - o.getAbsoluteSupport();
		if(compare !=0){
			return compare;
		}

		return this.hashCode() - o.hashCode();
	}

	/**
	 * Get the number of itemsets in this sequential pattern.
	 * @return the number of itemsets.
	 */
	public int size(){
		return itemsets.size();
	}
}


