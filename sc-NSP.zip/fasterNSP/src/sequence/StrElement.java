package sequence;


/**
 * <title>Element Class</title>
 * Element of Sequence, basic operation of Element
 */

public class StrElement {

    private String[] itemset;//all items in a StrElement 
    // private boolean Relation=RelationOR;   //relation between all items
    							//And:  such as -1 -2 -3, it means -(1 2 3)
    							//Or:   such as -1 -2 -3, it means (-1,-2,-3)
    
    //public StrElement(){
    //	 this.itemset = new int[1];
    //}
    
    public StrElement(String[] items){
   	 	this.itemset = new String[items.length];
   	 	for (int i=0;i<items.length;i++){
   	 		this.itemset[i] = items[i];
   	 	}
    }
    
    public StrElement(int arrayLength){
   	 	this.itemset = new String[arrayLength];
    }
    
    public StrElement(StrElement clone){
    	this.itemset = new String[clone.size()]; 
    	for (int i=0;i<clone.size();i++){
    		this.itemset[i] = clone.itemset[i];
    	}    	
    } 
   
     /**
     * get all items in the StrElement
     */
    public String[] getItems(){    	
        return this.itemset;
    }
    
    /**
     * get the item of index
     */
    public String getItem(int index){    	
    	if( this.itemset.length > index ){
            return itemset[index];
        }
        else{
        	System.err.println("StrElement.getItem(index), index="+ index + " is greater than itemset.length="+ itemset.length);
            return "";
        }    	
    }

    /**
     * remove the item of index
     */
    public String removeItem(int index){   
    	int iOldLength = itemset.length;
    	String ireturn = "";
    	String[] newitems = new String[iOldLength-1];
    	for (int i=0;i<iOldLength;i++){
    		if (i<index)
    			newitems[i] = itemset[i];
    		if (i==index)
    			ireturn = itemset[i];
    		if (i>index)
    			newitems[i-1] = itemset[i];
    	}
    	itemset = null;
    	itemset = new String[iOldLength-1];
    	itemset = newitems;
    	
    	return ireturn;
    }
    
    /**
     * add an item
     */
    public void addItem(String item){    	
    	int iOldLength = itemset.length;
    	String[] newitems = new String[iOldLength+1];
    	for (int i=0;i<iOldLength;i++){
    		newitems[i] = itemset[i];
    		if (itemset[i]==item) return;
    	}
    	newitems[iOldLength] = item;
    	itemset = null;
    	itemset = new String[iOldLength+1];
    	itemset = newitems;	
    	
    	itemSort();
    }
    
    
    /**
     * get the last item
     */
    public String getLastItem(){
    	return getItem(this.itemset.length-1);
    }

    /**
     * get the first item
     */
    public String getFirstItem(){
    	return getItem(0);
    }        
    
    /**
     * set the item value in index
     */
    ///*
    public void setItem(int arrayPosition, String ivalue){        
    	if (arrayPosition>=0 && arrayPosition<itemset.length){
    		itemset[arrayPosition]=ivalue;
    	} else {
    		//System.err.println("StrElement.setItem, Position="+ arrayPosition + " is invalid / itemset.length="+ itemset.length);
    	}    	
    	itemSort();
    } 
    
    /**
     * verify whether this StrElement is contain in StrElement e
     */
    public boolean isContainIn(StrElement e){    	
    	
    	boolean result = false;
    	if(this.itemset.length > e.itemset.length){
    		//if length of this StrElement is greater than the StrElement e, they are different
            return false;
        }

        int i=0,j=0;
        while( j<e.size() && i<this.size() ){
        	String ivalue = this.getItem(i);
        	String jvalue = e.getItem(j);
        	if (ivalue.equals(jvalue)){
        	    i++;j++;
        	}else{
        		j++;
        	}                        
        }

        if(i==this.size()){
            result = true;
        }else{
            result = false;
        }
        
    	return result;
    }
    
    /**
     * verify whether this StrElement is contain in StrElement e
     */
    public boolean isContainInNeg(StrElement e){    	
    	
    	if(this.size() > e.size()){
    		//if length of this StrElement is greater than the StrElement e, they are different
            return false;
        }

    	for (int i=0; i<this.size(); i++){
    		String ivalue = this.getItem(i);        	
    		for (int j=0; j<e.size(); j++){
    			String jvalue = e.getItem(j);
    			if (ivalue.substring(0,1)=="-" && ivalue.substring(1).equals(jvalue)){
    				return false;
    			}
    			if (jvalue.substring(0,1)=="-" && jvalue.substring(1).equals(ivalue)){
    				return false;
    			}
    		}
    	}
    	
    	return true; 
    }
    
    
    /**
     * verify whether this StrElement contains an item iItem
     */
    /*
    public boolean isContains(int iItem){
    	
       	boolean result = false;
    		
       	int i=0;
        while( i < this.size() ){
        	int ivalue = this.getItem(i);
        	if (ivalue == iItem){        
        		break;
        	}   
        	i++;
        }

        if( i < this.size() ){
            result = true;
        }else{
            result = false;
        }            
    	
    	return result;
    }
    */
    
    /**
     * verify whether this StrElement is match StrElement e
     */
    /*
    public boolean isMatch(StrElement e){
    	
    	boolean result = false;
    	int i=0,j=0;
        while( j < e.size() && i < this.size() ){
        	int ivalue = this.getItem(i);
        	int jvalue = e.getItem(j);
        	// + + or - - compare
            if ( ivalue * jvalue > 0){ 
            	if (ivalue == jvalue){
            	    i++;j++;
            	} else{
            		j++;
            	}
            }
            // + - or - + compare
            if ( ivalue * jvalue < 0 ){  
            	if (ivalue != -jvalue){
            	    i++;j++;
            	} else{
            		j++;
            	}
            }            
        }

        if(i==this.size()){
            result = true;
        }else{
            result = false;
        }
        
        return result;  	
    }*/
    
    /**
     * get StrElement without first item
     */
    public StrElement getWithoutFistItem(){
    	StrElement e = new StrElement(this.size()-1);
        for(int i=1 ; i<this.size() ; i++){
        	e.itemset[i-1] = itemset[i];
        }
       
        return e;
    }
  
    /**
     * get StrElement without last item
     */
    public StrElement getWithoutLastItem(){
    	StrElement e = new StrElement(this.size()-1);
        for(int i=0 ; i<this.size()-1 ; i++){
        	e.itemset[i] = itemset[i];
        }
       
        return e;
    }

    /**
     * get StrElement size
     */
    public int size(){
        return this.itemset.length;
    }

    /**
     * copy an StrElement as this StrElement
     */
    public StrElement clone(){
        StrElement clone=new StrElement(this);
        return clone;
    }
    
    /**
     * compare this StrElement with object o
     */
    public boolean equalsTo(Object o){

    	boolean equal=true;

        StrElement e=(StrElement)o;

        if(this.size()!=e.size()){//different size, not equal
            return false;
        }
        for(int i=0;equal && i<this.size();i++){
            if(this.getItem(i)!=e.getItem(i)){
                return false;
            }
        }
        return equal;
   }

    /**
     * overload toString()
     */
    public String toString(){
        StringBuffer s = new StringBuffer();
        for (int i = 0; i < this.size(); i++) {
            s.append(this.getItem(i));
            if (i != this.size() - 1) {
                s.append(",");
            }
        }
        return s.toString();
    }
    
    private void itemSort(){
    	String temp=""; 
    	for (int i = 0; i < itemset.length ; i++){
    		for (int j = 0; j <itemset.length - i - 1; j++){
    			if (itemset[j].compareTo(itemset[j + 1])>0){ //������ĳɴ��ڣ�����������
    				temp=itemset[j];
    				itemset[j]=itemset[j + 1];
    				itemset[j + 1]=temp;
    			} 
    		}
    	}
    }

}

