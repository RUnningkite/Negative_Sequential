package sequence;


import java.util.Hashtable;

/**
 * <title>Hash Table for Sequence Class</title>
 * Every sequence is composed of some elements
 */

public class SequenceHash {

	private Hashtable seqHash;
	
	public SequenceHash(){
		seqHash = new Hashtable();
	}
	
    public boolean isContains(Sequence seq) {

    	if (seqHash.containsKey(seq.toString().hashCode())){
    		int j=0;
			while (j<20){			
				if (seqHash.get(seq.toString().hashCode()+j)!=null)
					if (seqHash.get(seq.toString().hashCode()+j).toString().equals(seq.toString())){							
						return true;
					}
				j++;
			}	
		}
        return false;
    }
    
   
    public void put(Sequence seq){    	
    	if (!this.isContains(seq)){
    		int i=0;
    		while (i<20){
    			if (seqHash.containsKey(seq.toString().hashCode()+i)) {
    				i++;
    			} else{
    				break;
    			}
    		}				
    		seqHash.put(seq.toString().hashCode()+i,new Sequence(seq));
    	}
    }
    
    
    public boolean isContains(StrSequence seq) {

    	if (seqHash.containsKey(seq.toString().hashCode())){
    		int j=0;
			while (j<20){			
				if (seqHash.get(seq.toString().hashCode()+j)!=null)
					if (seqHash.get(seq.toString().hashCode()+j).toString().equals(seq.toString())){							
						return true;
					}
				j++;
			}	
		}
        return false;
    }
    
   
    public void put(StrSequence seq){    	
    	if (!this.isContains(seq)){
    		int i=0;
    		while (i<20){
    			if (seqHash.containsKey(seq.toString().hashCode()+i)) {
    				i++;
    			} else{
    				break;
    			}
    		}				
    		seqHash.put(seq.toString().hashCode()+i,new StrSequence(seq));
    	}
    }
    
    
    
    public int size(){
    	return seqHash.size();
    }
    
    public Hashtable getHashTable(){
    	return seqHash;
    }
    
}
