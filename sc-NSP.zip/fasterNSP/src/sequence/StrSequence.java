package sequence;

import java.util.ArrayList;
import java.util.Hashtable;


/**
 * <title>Sequence Class</title>
 * Every sequence is composed of some elements
 */

public class StrSequence {

    private int support; //support count  // n-contains
    private int cover;   //n-cover
    private ArrayList<StrElement> sequence; //sequence
    //private String label;
    
    public StrSequence() {
        this.sequence = new ArrayList<StrElement>();
        this.support = 0;
        this.cover = 0;
    }

    public StrSequence(StrSequence s) {
        this.sequence = new ArrayList<StrElement>();
        this.support = 0;
        this.cover = 0;
        for (int i = 0; i < s.size(); i++) {
            this.sequence.add(new StrElement(s.getElement(i)));
        }
    }

    /**
     * add new StrElement to a sequence
     */
    public void addElement(StrElement e) {
        this.sequence.add(e);
    }

    /**
     * add a new sequence to this sequence
     */
    public void addSeq(StrSequence seq) {
        for(StrElement e: seq.getElements()){
        	this.sequence.add(new StrElement(e));
        }
    }

    /**
     * insert an element into position index
     */
    public void insertElement(int index,StrElement e){
        this.sequence.add(index,e);
    }

    /**
     * delete an element from sequence
     */
    public StrElement removeElement(int index){
        if(index<this.sequence.size()){
            return this.sequence.remove(index);
        }else {
        	System.err.println("index is greater than sequence.size()");
            return null;
        }
    }    

    /**
     * get element in position index
     */
    public StrElement getElement(int index) {
        if (index >= 0 && index < this.sequence.size()) {
            return this.sequence.get(index);
        } else {
            System.err.println("index outof bound in Seuqence.getStrElement()");
            return null;
        }
    }

    /**
     * get all elements in sequence
     */
    public ArrayList<StrElement> getElements() {
        return this.sequence;
    }

    /**
     * get the negative of this sequence
     */
    public StrSequence getNegativeStrSequence() {
    	StrSequence s = new StrSequence();
    	StrElement eseq;
    	for (StrElement e: this.getElements()){
    		eseq = new StrElement(e);
    		for (int i=0 ; i<eseq.size() ; i++){
    			eseq.setItem(i,"-"+eseq.getItem(i));
    		}
    		s.addElement(eseq);
    	}
    	return s;
    }

    /**
     * get the size of sequence
     */
    public int size() {
        return this.sequence.size();
    }

   /**
    * verify whether this sequence is contain in sequences set seqs
    */ 
    /*public boolean isInSeqs(ArrayList<StrSequence> seqs) {
       
    	for (int i=0 ; i<seqs.size() ; i++) {
    		StrSequence s=seqs.get(i);
            if ( this.size() == s.size() ){
            	for ( int j=0 ; j<s.size(); j++){
            		if ( this.getStrElement(j).toString().equals(s.getStrElement(j).toString())){
            			if (j==s.size()-1) return true;
            		} else {
            			break;
            		}
            	}
            }
        }
        return false;
    }*/
    
    public boolean isInSeqs(SequenceHash seqs) {
    	 return seqs.isContains(this);
    }
    
    /**
     * compare whether this sequence is a subsequence of another sequence s
     */
    /*
    public boolean isSubsequenceOf(StrSequence s) {

        int i = 0, j = 0;
        
        while (j < s.size() && i < this.sequence.size()) {
            if (this.getStrElement(i).isContainIn(s.getStrElement(j))) {
            	i++;
                j++;
                if (i == this.sequence.size()) {
                    return true;
                }
            } else {
                j++;
            }
        }
        return false;
    }  */
  

    /**
     * increase support count
     */
    public void incrementSupport() {
        this.support++;
    }
    
    /**
     * increase cover count
     */
    public void incrementCover() {
        this.cover++;
    }
    
    /**
     * verify whether this sequence has more than 2 continual negative items
     */
    public boolean hasTwoNeg() {
    	int count=0;
        for (StrElement e: this.getElements()){
        	if (e.getFirstItem().toString().substring(0,1)!="-") count=0;
        	if (e.getFirstItem().toString().substring(0,1)=="-"){
        		count++;
        		if (count>=2) return true;
        	}
        }
        return false;
    }
    
    /**
     * get support
     */
    public int getSupport() {
        return this.support;
    }
    
    /**
     * set support
     */
    public void setSupport(int sup) {
        this.support = sup;
    }
    
    /**
     * get cover
     */
    public int getCover() {
        return this.cover;
    }
    
    /**
     * set cover
     */
    public void setCover(int cov) {
        this.cover = cov;
    }
    
    /**
     * overload toString()
     */
    public String toString() {
        StringBuffer s = new StringBuffer();
        s.append("<");
        for (int i = 0; i < this.sequence.size(); i++) {
        	StrElement e = sequence.get(i);
        	if (e.size()!=1) s.append("(");
            s.append(this.sequence.get(i));
            if (e.size()!=1) s.append(")");
            if (i != this.sequence.size() - 1) {
                s.append(" ");
            }
        }
        s.append(">");
        return s.toString();
    }
    
    /**
     * output the sequence and its support count
     */
    public String outputToString() {

        StringBuffer s = new StringBuffer();
        s.append("<");
        for (int i = 0; i < this.sequence.size(); i++) {
        	StrElement e = sequence.get(i);
        	if (e.size()!=1) s.append("(");
        	s.append(this.sequence.get(i));
        	if (e.size()!=1) s.append(")");            
            if (i != this.sequence.size() - 1) {
                s.append(" ");
            }
        }
        s.append(">");
        //s.append(" " + label);        
        s.append("["+ this.support+"]");
        s.append("["+ this.cover+"]");
        return s.toString();
    }
    
    /**
     * get all positive elements from a sequence
     */
    public StrSequence getPosFromSeq(){
    	StrSequence seq = new StrSequence();
    	for (int i=0 ; i<this.size() ; i++){
    		StrElement e = this.getElement(i);
    		if (e.getFirstItem().toString().substring(0,1)!="-"){
    			seq.addElement(e);
    		}
    	}
    	return seq; 
    }
    
    /**
     * transform a sequence into it's positive by change negative elements to positive elements
     */
    public StrSequence getCounterExample(){
    	StrSequence seq = new StrSequence();
    	for (int i=0 ; i<this.size() ; i++){
    		StrElement e = new StrElement(this.getElement(i));
    		if (e.getFirstItem().toString().substring(0,1)!="-"){
    			seq.addElement(e);
    		} else {
    			e.setItem(0,"-"+e.getFirstItem());
    			seq.addElement(e);
    		}
    	}
    	return seq; 
    }
    
    /**
     * get all negative elements from a sequence
     * output: all negative elements sequence
     */
    public StrSequence getNegFromSeq(){
    	StrSequence seq = new StrSequence();
    	for (int i=0 ; i<this.size() ; i++){
    		StrElement e = this.getElement(i);
    		if (e.getFirstItem().toString().substring(0,1)=="-"){
    			seq.addElement(e);
    		}
    	}
    	return seq;   	
    }
    
    /**
     * get a max sequence which its first item and last item are positive
     */
    public StrSequence getPosRangeFormSeq(){
    	StrSequence seq = new StrSequence(this);
    	if (seq.getElement(seq.size()-1).getFirstItem().toString().substring(0, 1)=="-"){
    		seq.removeElement(seq.size()-1);    	
    	}
    	if (seq.getElement(0).getFirstItem().toString().substring(0, 1)=="-"){
    		seq.removeElement(0);
    	}
    	
    	return seq;   
    }   
    
    
    /*
     * not finish yet
     * verify whether this sequence is match another sequence s
     * New one. hope it have better performance
     */
    public boolean isMatch(StrSequence s) {
    	boolean breturn= isNCover(s);
    	
    	//if (breturn) System.out.println("Mpa=" + this.toString() + "=seq=" + s.toString());   	
    	//if (!breturn) System.out.println("Npa=" + this.toString() + "=seq=" + s.toString());
    	
    	return  breturn;
    } 
    
    /*
     * n-cover method
     */
    public boolean isNCover(StrSequence s) {
    	boolean is = false;
    	
    	int iresult = n_cover(this,s,0,s.size()-1);
    	
    	if ( iresult >=0){
    		is = true;
    	}
    	
    	return is;    	
    } 
    
    private int n_cover(StrSequence pattern, StrSequence seq, int from, int to){
    	
    	int isMatch = -1;
    	//System.out.println("pat="+pattern.toString()+"=from="+from+"=to="+to+"=seq="+seq.toString());
    	StrElement ecurrent = pattern.getElement(0);
    	String iCurrentItem = ecurrent.getFirstItem();
    	
    	//StrSequence s0 = new StrSequence();
		//StrElement e0 = new StrElement(pattern.getStrElement(0)); // next element from current element.
		//s0.addStrElement(e0);	
		
		if ( iCurrentItem.substring(0, 1)!="-"){
    		for ( int i=from; i<=to; i++){
    			//int iSeqItem = seq.getStrElement(i).getFirstItem();
    			//if (iCurrentItem==iSeqItem){
    			StrElement eseq = seq.getElement(i);
    			if (ecurrent.isContainIn(eseq)){	
    				if (pattern.size()<=1){   // if pattern only have 1 element, it is leaf node;
    					//System.out.println(" return1 == " + i);
    					return i;
    				}else{    				
    					StrSequence s = new StrSequence(pattern);
        				s.removeElement(0);
        				int ireturn = n_cover(s,seq,i+1,to);
        				if (ireturn>=0){  //find
        					//System.out.println(" return2 == " + i);
        					return i;
        				} else {
        					//continue to search;
        					if (s.getElement(0).getFirstItem().toString().substring(0,1)!="-") return -1;
        					//else System.out.println("continue to search");
        					
        				}
    				}    				
    			}
    		}    		
    	}

    	if ( iCurrentItem.toString().substring(0,1)=="-" ){    		
    		if (pattern.size()<=1){  // only one negative element    			
    			for ( int i=from; i<=to; i++){
        			//int iSeqItem = seq.getStrElement(i).getFirstItem();
    				StrElement eseq = seq.getElement(i);
        			if (!ecurrent.isContainInNeg(eseq)){
        				//System.out.println(" return3 == -1");
        				return -1;   //find negative item
        			}
    			}
    			//System.out.println(" return4 == " + to);
    			return to;  //not find negative item
        		
    		} else {   // more than one element
    				
    			StrSequence s1 = new StrSequence(pattern);
    			s1.removeElement(0);	
    					
    			int ipos = n_cover(s1,seq,from,to);
    			
    			if (ipos>=0) {// find positive one, which follow current negative element.
    				for ( int i=from; i<=ipos; i++){
    					StrElement eseq = seq.getElement(i);
            			if (!ecurrent.isContainInNeg(eseq)){
            				//System.out.println(" return31 == -1");
            				return -1;   //find negative item
            			}
        			} 
    				//System.out.println(" return32 == " + ipos);
    				return ipos;
    			} else { // can't find next positive one
    				//System.out.println(" return33 == -1");
    				return -1;
    			}
    		}
    	}
    	//System.out.println(" return end == " + isMatch);
      	return isMatch;
    	
    }    
    
    /*
     * n-contain method
     */
    public boolean isNContain(StrSequence s) {
    	if ( this.isNCover(s) && !this.getCounterExample().isNCover(s) ){
    		return true;
    	} else {
    		return false;
    	}
    } 
    
    /*
     * n-include method
     */
    public boolean isNInclude(StrSequence s) {
    	boolean is = false;
    	
    	if (this.toString().equals("<2 -3>")){
    		//System.out.println("2 -3");
    	}
    	int iresult = n_include(this,s,0,s.size()-1);
    	
    	if ( iresult >= 0){
    		is = true;
    	}    	
    	return is;    	
    }
    
    private int n_include(StrSequence pattern, StrSequence seq, int from, int to){
    	
       	int isMatch = -1;
    	StrElement ecurrent = pattern.getElement(0);
    	String iCurrentItem = ecurrent.getFirstItem();
    	
    	if ( iCurrentItem.toString().substring(0,1)!="-" ){    		
    		for ( int i=from; i<=to; i++){
    			StrElement eseq = seq.getElement(i);
    			if (ecurrent.isContainIn(eseq)){	
    				if (pattern.size()<=1){   // if pattern only have 1 element, it is leaf node;
    					return i;
    				}else{    				
    					StrSequence s = new StrSequence(pattern);
        				s.removeElement(0);
        				int ireturn = n_include(s,seq,i+1,to);
        				if (ireturn>=0){  //find
        					return i;
        				} else {
        					return -1;
        				}
    				}    				
    			}
    		}
    		
    	}

    	if ( iCurrentItem.toString().substring(0,1)=="-" ){    			
    		if (pattern.size()<=1){   // if pattern only have 1 element, it is leaf node;
				return from;
			}else{    				
				StrSequence s = new StrSequence(pattern);
				s.removeElement(0);
				int ireturn = n_include(s,seq,from,to);
				return ireturn;
			} 
    	}
    	return isMatch;
    	
    }    
    
    public void setLabel(String strlabel){
    	//this.label = strlabel;
    }
    
    //public String getLabel(){
    	//return this.label;
    //}
    
    
    /*
     * verify whether this sequence is match another sequence s
     */
    /*
    public boolean isMatchOld(StrSequence s) {

    	int isize = this.size();
    	int ssize = s.size();
    	
    	ArrayList[] pos = new ArrayList[isize];    	
    	
    	//save every position
    	int FirstPosItem = -1;
    	int PrePositive = 0;
    	for (int j=0; j<isize; j++){
    		int i=PrePositive;
    		StrElement ej = this.getStrElement(j);
    		if (pos[j]==null) pos[j]=new ArrayList<Integer>();
    		if (FirstPosItem==-1 && ej.getFirstItem()>0) FirstPosItem =j;
            while (i < ssize ) {  // && i < this.sequence.size()
            	StrElement e = s.getStrElement(i);
            	int ivalue = ej.getItem(0); 
        		if (ivalue>0 && e.isContains(ivalue)){
        			pos[j].add(i+1);                		
            	}
            	if (ivalue<0 && e.isContains(-ivalue)){
            		pos[j].add(-(i+1));
            	}
        		i++;
        	} 
            if (ej.getFirstItem()>0 && pos[j].size()>0) PrePositive = (Integer) pos[j].get(0);
            if (this.getStrElement(j).getItem(0)>0 && pos[j].size()<=0) return false;
        }
        
    	//
        boolean isEnd = false;
        int[] position = new int[pos.length];
        for (int j=0; j<pos.length; j++){
        	position[j]=0;
        }
        int lastpos = 0;
        while (!isEnd){
        	int sumDiff = 0;
        	lastpos = 0;
        	for (int k=0; k<pos.length-1; k++){
        		int i1=0,i2=0;
        		
        		StrElement ele = this.getStrElement(k);
        		sumDiff = sumDiff + 1;
        		
        		if (position[k]<pos[k].size()) i1 = (Integer)(pos[k].get(position[k]));
        		if (position[k+1]<pos[k+1].size()) i2 = (Integer)(pos[k+1].get(position[k+1]));
        		
        		if ( i1 > 0) {
        			if (i1>lastpos){ 
        				lastpos = i1;
        			}
        		}
        		//else break;
        		if ( i2 > 0 ){
        			//position[k+1]=0;
        			while ( i2 <= lastpos + sumDiff -1 ){
        				position[k+1]++;
            			if ( position[k+1] >= pos[k+1].size() ){
            				return false; 
            			} else {
            				i2 = (Integer)(pos[k+1].get(position[k+1]));            				
            			}
            		}
        			lastpos = i2;   
        			sumDiff = 0;
        		}
        	}
        	//negative item
        	boolean isneg = false;
        	for (int k=0; k<pos.length; k++){
        		int i1=0,ip=0,in=s.size();
        		if (position[k]<pos[k].size()) i1 = (Integer)(pos[k].get(position[k]));
        		if ( i1<0 ){
        			if ((k+1)<pos.length && position[k+1]<pos[k+1].size()) in = (Integer)(pos[k+1].get(position[k+1]));
        			if ((k-1)>=0 && position[k-1]<pos[k-1].size()) ip = (Integer)(pos[k-1].get(position[k-1]));            		
        			for (int m=0; m<pos[k].size(); m++){
        				i1 = (Integer)(pos[k].get(m));        				
        				if (Math.abs(i1)<in && Math.abs(i1)>ip){ isneg = true; break;}
        			}        			
        		}        		
        	}        	
        	if (!isneg) { 
        		return true;
        	}
        	else {
        		if (FirstPosItem==-1) {
        			return false;         			 
        		}
        		else position[FirstPosItem]++;
        	}
        	
        	if (position[FirstPosItem]>=pos[FirstPosItem].size()) isEnd = true;
        }
        
        return false;

    } */
}

