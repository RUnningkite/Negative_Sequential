package sequence;
  
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;




/**
 * <title>Sequence Class</title>
 * Every sequence is composed of some elements
 */

public class Sequence {
 
    private int support; //support count  // n-contains
    private int cover;   //n-cover
    private ArrayList<Element> sequence; //sequence
    //private String label;
    private int id;
    
    public Sequence() {
        this.sequence = new ArrayList<Element>();
        this.support = 0;
        this.cover = 0;
        
    }

    public Sequence(Sequence s) {
        this.sequence = new ArrayList<Element>();
        this.support = 0;
        this.cover = 0;
        for (int i = 0; i < s.size(); i++) {
            this.sequence.add(s.getElement(i));
        }
    }
    
    public Sequence(int id){
    	
    	this.id=id;
    }

    /**
     * add new Element to a sequence
     */
    public void addElement(Element e) {
    	//System.out.println("---------23145789---"+e);
    	//sequence.add(e);
       this.sequence.add(e);
       // System.out.println("---------23145789---"+sequence);
    }

    /**
     * add a new sequence to this sequence
     */
    public void addSeq(Sequence seq) {
        for(Element e: seq.getElements()){
        	this.sequence.add(e);
        }
    }

    /**
     * insert an element into position index
     */
    public void insertElement(int index,Element e){
        this.sequence.add(index,e);
    }

    /**
     * delete an element from sequence
     */
    public Element removeElement(int index){
        if(index<this.sequence.size()){
            return this.sequence.remove(index);
        }else {
        	System.err.println("index is greater than sequence.size()");
            return null;
        }
    }    

    /**
     * get element in position index
     */
    public Element getElement(int index) {
        if (index >= 0 && index < this.sequence.size()) {
            return this.sequence.get(index);
        } else {
            System.err.println("index outof bound in Seuqence.getElement()");
            return null;
        }
    }
    
    

    /**
     * get all elements in sequence
     */
    public ArrayList<Element> getElements() {
        return this.sequence;
    }

    /**
     * get the negative of this sequence
     */
    public Sequence getNegativeSequence() {
    	Sequence s = new Sequence();
    	Element eseq;
    	for (Element e: this.getElements()){
    		eseq=e;
    		eseq.setItemsNeg();
    		//eseq.itemSort();
    		//for (int i=0 ; i<eseq.size() ; i++){
    		//	eseq.setItem(i,-eseq.getItem(i));
    		//}
    		s.addElement(eseq);
    	}
    	return s;
    }

    /**
     * get the size of sequence
     */
    public int size() {
        return this.sequence.size();
    }
    
    public int itemsize() {
    	//System.out.println("111111111111111111111111111");
    	int isize = 0;
        for (int i=0; i< sequence.size(); i++){
        	isize = isize + sequence.get(i).size();
        }
        //System.out.println("111111111111111111111111111");
    	return isize;
    }

   /**
    * verify whether this sequence is contain in sequences set seqs
    */ 
    /*public boolean isInSeqs(ArrayList<Sequence> seqs) {
       
    	for (int i=0 ; i<seqs.size() ; i++) {
    		Sequence s=seqs.get(i);
            if ( this.size() == s.size() ){
            	for ( int j=0 ; j<s.size(); j++){
            		if ( this.getElement(j).toString().equals(s.getElement(j).toString())){
            			if (j==s.size()-1) return true;
            		} else {
            			break;
            		}
            	}
            }
        }
        return false;
    }*/
    
    public boolean isInSeqs(SequenceHash seqs) {
    	 return seqs.isContains(this);
    }
    
    /**
     * compare whether this sequence is a subsequence of another sequence s
     */
    /*
    public boolean isSubsequenceOf(Sequence s) {

        int i = 0, j = 0;
        
        while (j < s.size() && i < this.sequence.size()) {
            if (this.getElement(i).isContainIn(s.getElement(j))) {
            	i++;
                j++;
                if (i == this.sequence.size()) {
                    return true;
                }
            } else {
                j++;
            }
        }
        return false;
    }  */
  

    /**
     * increase support count
     */
    public void incrementSupport() {
        this.support++;
    }
    
    /**
     * increase cover count
     */
    public void incrementCover() {
        this.cover++;
    }
    
    /**
     * verify whether this sequence has more than 2 continual negative items
     */
    public boolean hasTwoNeg() {
    	int count=0;
        for (Element e: this.getElements()){
        	if (e.getFirstItem()>0) count=0;
        	if (e.getFirstItem()<0){
        		count++;
        		if (count>=2) return true;
        	}
        }
        return false;
    }
    
    /**
     * get id
     */
    public int getId(){
    	//System.out.println("---------2314---");
    	return id;
		
    }
    /**
     * set id
     */
    public void setId(int i){
    	this.id = i;
    }
    
    /**
     * get support
     */
    public int getSupport() {
        return this.support;
    }
    
    /**
     * set support
     */
    public void setSupport(int sup) {
        this.support = sup;
    }
    
    /**
     * get cover
     */
    public int getCover() {
        return this.cover;
    }
    
    /**
     * set cover
     */
    public void setCover(int cov) {
        this.cover = cov;
    }
    
    /**
     * overload toString()
     */
    public String toString() {
        StringBuffer s = new StringBuffer();
        s.append("<");
        for (int i = 0; i < this.sequence.size(); i++) {
            s.append(this.sequence.get(i));
            if (i != this.sequence.size() - 1) {
                s.append(" ");
            }
        }
        s.append(">");
        return s.toString();
    }
    
    /**
     * output the sequence and its support count
     */
    public String outputToString() {

        StringBuffer s = new StringBuffer();
        s.append("<");
        for (int i = 0; i < this.sequence.size(); i++) {
        	Element e = sequence.get(i);
        	if (e.size()!=1) s.append("(");
        	s.append(this.sequence.get(i));
        	if (e.size()!=1) s.append(")");            
            if (i != this.sequence.size() - 1) {
                s.append(" ");
            }
        }
        s.append(">");
        //s.append(" " + label);        
        s.append("["+ this.support+"]");
        s.append("["+ this.cover+"]");
        return s.toString();
    }
    
    /**
     * get all positive elements from a sequence
     */
    public Sequence getPosFromSeq(){
    	Sequence seq = new Sequence();
    	for (int i=0 ; i<this.size() ; i++){
    		Element e = this.getElement(i);
    		if (e.getFirstItem()>0){
    			seq.addElement(e);
    		}
    	}
    	return seq; 
    }
    
    /**
     * transform a sequence into it's positive by change negative elements to positive elements
     */
    public Sequence getCounterExample(){
    	Sequence seq = new Sequence();
    	for (int i=0 ; i<this.size() ; i++){
    		Element e = new Element();
    	    for(Integer j : this.getElement(i).getItems()){
    	    	e.addItem(j);
    	    }
    			//e=	this.getElement(i);
    			
    	//	System.out.println("eee"+e);
    		if (e.getFirstItem()>0){
    			seq.addElement(e);
    		} else {    			
    			//for (int j=e.size()-1 ; j>=0; j--) {
    			//	e.setItem(j,-e.getItem(j));
    			//}
    		//	System.out.println("eth"+this.getElement(i));
    			e.setItemsNeg();
    		//	System.out.println("eee"+e);
    		//	System.out.println("eth"+this.getElement(i));
    			seq.addElement(e);
    		}
    	}
    	return seq; 
    }
    
    public Sequence getCounterExampleX(int index){
    	Sequence seq = new Sequence();
    	int iindex = 0;
    	for (int i=0 ; i<this.size() ; i++){
    		Element e = this.getElement(i).clone();//
    		if (e.getFirstItem()>0){
    			seq.addElement(e);
    		} else {    	
    			if (index == iindex){
    				//for (int j=e.size()-1 ; j>=0; j--) {
    				//	e.setItem(j,-e.getItem(j));
    				//}
    				e.setItemsNeg();
    				seq.addElement(e);    				
    			}
    			iindex ++;
    		}
    	}
    	return seq; 
    }
    
    
    /**
     * get all negative elements from a sequence
     * output: all negative elements sequence
     */
    public Sequence getNegFromSeq(){
    	Sequence seq = new Sequence();
    	for (int i=0 ; i<this.size() ; i++){
    		Element e = this.getElement(i);
    		if (e.getFirstItem()<0){
    			seq.addElement(e);
    		}
    	}
    	return seq;   	
    }
    
    /**
     * get a max sequence which its first item and last item are positive
     */
    public Sequence getPosRangeFormSeq(){
    	Sequence seq = new Sequence(this);
    	if (seq.getElement(seq.size()-1).getFirstItem()<0){
    		seq.removeElement(seq.size()-1);    	
    	}
    	if (seq.getElement(0).getFirstItem()<0){
    		seq.removeElement(0);
    	}
    	
    	return seq;   
    }   
    
    
    /*
     * not finish yet
     * verify whether this sequence is match another sequence s
     * New one. hope it have better performance
     */
    public boolean isMatch(Sequence s) {
    	boolean breturn= isNCover(s);
    	
    	//if (breturn) System.out.println("Mpa=" + this.toString() + "=seq=" + s.toString());   	
    	//if (!breturn) System.out.println("Npa=" + this.toString() + "=seq=" + s.toString());
    	
    	return  breturn;
    } 
    
    public boolean isXJNegMatch(Sequence sDataSequence) {
    	boolean breturn= false;
    	
    	Sequence seq = new Sequence(this);
    	ArrayList<Sequence> seqlist = new ArrayList<Sequence>();
    	
    	if (this.getPosFromSeq().size()==0){
    		breturn = true;
    	} else if (this.getPosFromSeq().isMatch(sDataSequence)){
    		breturn = true;
    	} else{
    		return false;
    	}
    	
    	if (this.getCounterExample().isNCover(sDataSequence)){
			return false;
		}
    	
    	
    	for (int i=0; i<seq.size(); i++){
    		if (seq.getElement(i).getFirstItem()<0){
    			Sequence newseq = new Sequence(seq);
    			newseq.getElement(i).setItemsNeg();
    			for (int j=newseq.size()-1; j>=0; j--){
    				if (newseq.getElement(j).getFirstItem()<0){
    					newseq.removeElement(j);
    				}
    			}
    			seqlist.add(newseq);
    		}    		
    	}
    	
    	for ( int i=0; i<seqlist.size(); i++){
    		if (seqlist.get(i).getCounterExample().isNCover(sDataSequence)){
    			return false;
    		}
    	}
    	
    	return  breturn;
    } 
    
    /*
     * n-cover method
     */
    public boolean isNCover(Sequence s) {
    	boolean is = false;
    	
    	int iresult = n_cover(this,s,0,s.size()-1);
    	
    	if ( iresult >=0){
    		is = true;
    	}
    	
    	return is;    	
    } 
    
    private int n_cover(Sequence pattern, Sequence seq, int from, int to){
    	
    	int isMatch = -1;
    	//System.out.println("pat="+pattern.toString()+"=from="+from+"=to="+to+"=seq="+seq.toString());
    	Element ecurrent = pattern.getElement(0);
    	int iCurrentItem = ecurrent.getFirstItem();
    	
    	//Sequence s0 = new Sequence();
		//Element e0 = new Element(pattern.getElement(0)); // next element from current element.
		//s0.addElement(e0);	
		
		if ( iCurrentItem>0 ){
    		for ( int i=from; i<=to; i++){
    			//int iSeqItem = seq.getElement(i).getFirstItem();
    			//if (iCurrentItem==iSeqItem){
    			Element eseq = seq.getElement(i);
    			if (ecurrent.isContainIn(eseq)){	
    				if (pattern.size()<=1){   // if pattern only have 1 element, it is leaf node;
    					//System.out.println(" return1 == " + i);
    					return i;
    				}else{    				
    					Sequence s = new Sequence(pattern);
        				s.removeElement(0);
        				int ireturn = n_cover(s,seq,i+1,to);
        				if (ireturn>=0){  //find
        					//System.out.println(" return2 == " + i);
        					return i;
        				} else {
        					//continue to search;
        					if (s.getElement(0).getFirstItem()>0) return -1;
        					//else System.out.println("continue to search");
        					
        				}
    				}    				
    			}
    		}    		
    	}

    	if ( iCurrentItem<0 ){    		
    		if (pattern.size()<=1){  // only one negative element    			
    			for ( int i=from; i<=to; i++){
        			//int iSeqItem = seq.getElement(i).getFirstItem();
    				Element eseq = seq.getElement(i);
        			if (!ecurrent.isContainInNeg(eseq)){
        				//System.out.println(" return3 == -1");
        				return -1;   //find negative item
        			}
    			}
    			//System.out.println(" return4 == " + to);
    			return to;  //not find negative item
        		
    		} else {   // more than one element
    				
    			Sequence s1 = new Sequence(pattern);
    			s1.removeElement(0);	
    					
    			int ipos = n_cover(s1,seq,from,to);
    			
    			if (ipos>=0) {// find positive one, which follow current negative element.
    				for ( int i=from; i<=ipos; i++){
    					Element eseq = seq.getElement(i);
            			if (!ecurrent.isContainInNeg(eseq)){
            				//System.out.println(" return31 == -1");
            				return -1;   //find negative item
            			}
        			} 
    				//System.out.println(" return32 == " + ipos);
    				return ipos;
    			} else { // can't find next positive one
    				//System.out.println(" return33 == -1");
    				return -1;
    			}
    		}
    	}
    	//System.out.println(" return end == " + isMatch);
      	return isMatch;
    	
    }    
    
    /*
     * n-contain method
     */
    public boolean isNContain(Sequence s) {
    	if ( this.isNCover(s) && !this.getCounterExample().isNCover(s) ){
    		return true;
    	} else {
    		return false;
    	}
    } 
    
    /*
     * n-include method
     */
    public boolean isNInclude(Sequence s) {
    	boolean is = false;
    	
    	if (this.toString().equals("<2 -3>")){
    		//System.out.println("2 -3");
    	}
    	int iresult = n_include(this,s,0,s.size()-1);
    	
    	if ( iresult >= 0){
    		is = true;
    	}    	
    	return is;    	
    }
    
    private int n_include(Sequence pattern, Sequence seq, int from, int to){
    	
       	int isMatch = -1;
    	Element ecurrent = pattern.getElement(0);
    	int iCurrentItem = ecurrent.getFirstItem();
    	
    	if ( iCurrentItem>0 ){
    		for ( int i=from; i<=to; i++){
    			Element eseq = seq.getElement(i);
    			if (ecurrent.isContainIn(eseq)){	
    				if (pattern.size()<=1){   // if pattern only have 1 element, it is leaf node;
    					return i;
    				}else{    				
    					Sequence s = new Sequence(pattern);
        				s.removeElement(0);
        				int ireturn = n_include(s,seq,i+1,to);
        				if (ireturn>=0){  //find
        					return i;
        				} else {
        					return -1;
        				}
    				}    				
    			}
    		}
    		
    	}

    	if ( iCurrentItem<0 ){    		
    		if (pattern.size()<=1){   // if pattern only have 1 element, it is leaf node;
				return from;
			}else{    				
				Sequence s = new Sequence(pattern);
				s.removeElement(0);
				int ireturn = n_include(s,seq,from,to);
				return ireturn;
			} 
    	}
    	return isMatch;
    	
    }    
    
    public void setLabel(String strlabel){
    	//this.label = strlabel;
    }
    
    public Sequence cloneSequenceMinusItems(HashMap<Integer, Set<Integer>> mapSequenceID, double relativeMinSup) {
    	
    	// create a new sequence
    	//Sequence seq = new Sequence(getId());
    	Sequence seq = new Sequence();
    	seq.id=getId();
    	// for each  itemset in the original sequence
    	for(Element e : sequence){
    		//System.out.println("eee"+e);
    		// call a method to copy this itemset 璋冪敤涓�涓柟娉曟潵澶嶅埗杩欎釜itemset
    		Element newe = cloneItemsetMinusItems(e,mapSequenceID,relativeMinSup);
    		//System.out.println(newe);
    		//add the copy to the new sequence
    		if(newe.size() !=0){
    			//System.out.println("---------231433333---"+newe);
    			seq.addElement(newe);
    			//System.out.println("---------23145---"+seq.size());
    			
    		}
    		
    	}
    	
    	return seq;
  }
     
    /**
	 * Make a copy of an itemset while removing some items
	 * that are infrequent with respect to a threshold minsup.
	 * @param mapSequenceID a map with key = item  value = a set of sequence ids containing this item
	 * @param minSupportAbsolute the minimum support threshold chosen by the user.
	 * @param itemset the itemset
	 * @return a copy of this itemset except that item(s) with a support lower than minsup have been excluded.
	 */
    
    public Element cloneItemsetMinusItems(Element element,Map<Integer, Set<Integer>> mapSequenceID, double minSupportAbsolute) {
    	// create a new itemset
    	//System.out.println(minSupportAbsolute);
    	//System.out.println("eeeeeeee"+element+"size"+element.size());
    	//int i = 0;
    	Element newe = new Element();//zhuyi
    	//System.out.println("newe2  "+newe);
    	// for each item of the original itemset
    	for(Integer item : element.getItems()){
    		//System.out.println("item  "+item);
    		// get the sed of sequences containing this item
    		Set<Integer> sidSet = mapSequenceID.get(item);
    		//System.out.println("item  "+item);
    		//System.out.println("sidSet  "+sidSet.size());
    		// if this set is not null (an infrequent item) and the support is higher than minsup...
    		if(sidSet  !=null && sidSet.size() > minSupportAbsolute){
    			//System.out.println("itemyyyy"+item);
    			newe.addItem(item);;
    		//	i++;
    		
    		//	System.out.println("newetttt"+newe);
    		}
    	}
    	//System.out.println("newe"+newe);
    	return  newe;
    	
    }
    
    public Sequence clone(){
    	Sequence clone = new Sequence();
    	for(Element e : this.sequence){
    		Element ea = new Element();
    		ea = e.clone();
    		clone.addElement(ea);
    	}
    	return clone;
    }
    //public String getLabel(){
    	//return this.label;
    //}
    
    
    /*
     * verify whether this sequence is match another sequence s
     */
    /*
    public boolean isMatchOld(Sequence s) {

    	int isize = this.size();
    	int ssize = s.size();
    	
    	ArrayList[] pos = new ArrayList[isize];    	
    	
    	//save every position
    	int FirstPosItem = -1;
    	int PrePositive = 0;
    	for (int j=0; j<isize; j++){
    		int i=PrePositive;
    		Element ej = this.getElement(j);
    		if (pos[j]==null) pos[j]=new ArrayList<Integer>();
    		if (FirstPosItem==-1 && ej.getFirstItem()>0) FirstPosItem =j;
            while (i < ssize ) {  // && i < this.sequence.size()
            	Element e = s.getElement(i);
            	int ivalue = ej.getItem(0); 
        		if (ivalue>0 && e.isContains(ivalue)){
        			pos[j].add(i+1);                		
            	}
            	if (ivalue<0 && e.isContains(-ivalue)){
            		pos[j].add(-(i+1));
            	}
        		i++;
        	} 
            if (ej.getFirstItem()>0 && pos[j].size()>0) PrePositive = (Integer) pos[j].get(0);
            if (this.getElement(j).getItem(0)>0 && pos[j].size()<=0) return false;
        }
        
    	//
        boolean isEnd = false;
        int[] position = new int[pos.length];
        for (int j=0; j<pos.length; j++){
        	position[j]=0;
        }
        int lastpos = 0;
        while (!isEnd){
        	int sumDiff = 0;
        	lastpos = 0;
        	for (int k=0; k<pos.length-1; k++){
        		int i1=0,i2=0;
        		
        		Element ele = this.getElement(k);
        		sumDiff = sumDiff + 1;
        		
        		if (position[k]<pos[k].size()) i1 = (Integer)(pos[k].get(position[k]));
        		if (position[k+1]<pos[k+1].size()) i2 = (Integer)(pos[k+1].get(position[k+1]));
        		
        		if ( i1 > 0) {
        			if (i1>lastpos){ 
        				lastpos = i1;
        			}
        		}
        		//else break;
        		if ( i2 > 0 ){
        			//position[k+1]=0;
        			while ( i2 <= lastpos + sumDiff -1 ){
        				position[k+1]++;
            			if ( position[k+1] >= pos[k+1].size() ){
            				return false; 
            			} else {
            				i2 = (Integer)(pos[k+1].get(position[k+1]));            				
            			}
            		}
        			lastpos = i2;   
        			sumDiff = 0;
        		}
        	}
        	//negative item
        	boolean isneg = false;
        	for (int k=0; k<pos.length; k++){
        		int i1=0,ip=0,in=s.size();
        		if (position[k]<pos[k].size()) i1 = (Integer)(pos[k].get(position[k]));
        		if ( i1<0 ){
        			if ((k+1)<pos.length && position[k+1]<pos[k+1].size()) in = (Integer)(pos[k+1].get(position[k+1]));
        			if ((k-1)>=0 && position[k-1]<pos[k-1].size()) ip = (Integer)(pos[k-1].get(position[k-1]));            		
        			for (int m=0; m<pos[k].size(); m++){
        				i1 = (Integer)(pos[k].get(m));        				
        				if (Math.abs(i1)<in && Math.abs(i1)>ip){ isneg = true; break;}
        			}        			
        		}        		
        	}        	
        	if (!isneg) { 
        		return true;
        	}
        	else {
        		if (FirstPosItem==-1) {
        			return false;         			 
        		}
        		else position[FirstPosItem]++;
        	}
        	
        	if (position[FirstPosItem]>=pos[FirstPosItem].size()) isEnd = true;
        }
        
        return false;

    } */
}

