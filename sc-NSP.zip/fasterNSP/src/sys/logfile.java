package sys;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;


/**
 * Log file Class
 * @author zhigang
 * a class for log file output.
 */
public class logfile {
	private String LogFile;
	private PrintWriter log;
	private File f;
	
	public logfile(){
		try{
			LogFile = "C:\\Documents and Settings\\zgzheng\\Desktop\\GA Paper\\experiment\\experiment result\\a.txt";
			f = new File(LogFile);
			if (f.exists())	f.delete();		
			f.createNewFile();
		    log = new PrintWriter(new FileWriter(LogFile, true), true);
		}
		catch (Exception e) {
	    	e.printStackTrace();
	    }
	}
	
	public logfile(String filename){
		LogFile = filename;
		try{
			f = new File(LogFile);
			if (f.exists())	f.delete();		
			f.createNewFile();
		    log = new PrintWriter(new FileWriter(LogFile, true), true);
		}
		catch (Exception e) {
	    	e.printStackTrace();
	    }
	}
	
	public void print(String str){
		log.print(str);
	}
	
	public void println(String str){
		log.println(str);
	}
	
	public void setfilename(String filename){
		LogFile = filename;
	}
	
	public String getfilename(){
		return LogFile;
	}
	
	public void close(){
		if (log!=null) log.close();
	}
}
